#' Display a Summary of a Long Array
#'
#' This function displays a summary of a long array by showing the first and last few elements.
#'
#' @param array The input array to display.
#' @param num_elements Number of elements to display at the start and end (default is 3).
#' @return A summary of the array.
#' @examples
#' array <- 1:10
#' disp_array_summary(array) # Uses default num_elements
#' disp_array_summary(array, 2) # Uses custom num_elements
#'
#' @export
disp_array_summary <- function(array, num_elements = 3) {
  # Get the length of the array
  n <- length(array)

  # Check if the array length is less than or equal to twice the number of elements to display
  if (n <= 2 * num_elements) {
    # If the array is short, display all elements
    cat(sprintf("%s (Length: %d)\n", paste(array, collapse = ", "), n))
  } else {
    # Display the first few elements
    start_elements <- array[1:num_elements]

    # Display the last few elements
    end_elements <- array[(n - num_elements + 1):n]

    # Convert elements to strings without brackets
    start_str <- paste(start_elements, collapse = ", ")
    end_str <- paste(end_elements, collapse = ", ")

    # Display the summary
    cat(sprintf("%s ... %s (Length: %d)\n", start_str, end_str, n))
  }
}

#' Display a List of Lists in a Formatted Way
#'
#' This function displays a list of lists (acting as structs) in a formatted way.
#'
#' @param list_of_structs A list containing lists (which act as structs in R).
#' @return None
#' @examples
#' list_of_structs <- list(list(name = "John", age = 30), list(name = "Jane", age = 25))
#' disp_list_of_structs(list_of_structs)
#'
#' @export
disp_list_of_structs <- function(list_of_structs) {
  # Check if the input is a list
  if (!is.list(list_of_structs)) {
    stop("Input must be a list.")
  }

  # Iterate over each element in the list
  for (i in seq_along(list_of_structs)) {
    # Check if the element is a list (acting as a struct)
    if (!is.list(list_of_structs[[i]])) {
      stop("Each element of the list must be a list (struct).")
    }

    # Display the struct index
    # cat(sprintf("Struct %d:\n", i))

    # Get the field names of the struct
    fields <- names(list_of_structs[[i]])

    # Iterate over each field in the struct
    for (field_name in fields) {
      # Get the field value
      field_value <- list_of_structs[[i]][[field_name]]

      # Display the field name and value
      if (is.character(field_value)) {
        cat(sprintf("  %s: %s\n", field_name, field_value))
      } else if (is.numeric(field_value) || is.logical(field_value)) {
        cat(sprintf("  %s: %g\n", field_name, field_value))
      } else if (is.list(field_value)) {
        cat(sprintf("  %s: {list}\n", field_name))
      } else {
        cat(sprintf("  %s: [unknown type]\n", field_name))
      }
    }

    # Add a separator line for better readability
    cat("   ------------------------\n")
  }
}


#' Extract a Sub-list by Keys
#'
#' Extract a sub-list from the original list with elements specified in `keys_list`.
#'
#' @param original_list The original list to extract from.
#' @param keys_list A character vector of keys to include in the sub-list.
#' @return A sub-list containing only the specified keys.
#' @export
extract_sublist_by_keys <- function(original_list, keys_list) {
  sublist <- list()
  for (key in keys_list) {
    if (key %in% names(original_list)) {
      sublist[[key]] <- original_list[[key]]
    }
  }
  return(sublist)
}

#' Check if a List has Only Allowed Keys
#'
#' Verify if the input variable is a list and all its elements' names are within the allowed keys.
#'
#' @param input_list The list to check.
#' @param allowed_keys A character vector of allowed keys.
#' @return TRUE if the input_list is a list and all its names are in `allowed_keys`, FALSE otherwise.
#' @export
#' @examples
#' my_list <- list(a = 1, b = 2, c = 3)
#' allowed_keys <- c("a", "b", "c")
#' is_valid <- has_allowed_keys(my_list, allowed_keys)
#' print(is_valid) # TRUE
#'
#' my_list <- list(a = 1, b = 2, d = 4)
#' is_valid <- has_allowed_keys(my_list, allowed_keys)
#' print(is_valid) # FALSE
has_allowed_keys <- function(input_list, allowed_keys) {
  is_valid <- FALSE
  if (is.list(input_list) && !is.null(names(input_list))) {
    list_keys <- names(input_list)
    if (all(list_keys %in% allowed_keys)) {
      is_valid <- TRUE
    }
  }
  return(is_valid)
}


#' Set a List with Values from Another List
#'
#' Set the original list with values from the list to set. If a key in the original list
#' does not exist in the list to set, its value will be set to `NA`.
#'
#' @param original The original list to update.
#' @param list_to_set The list with values to set.
#' @return The updated list.
#' @export
#' @examples
#' original_list <- list(a = 1, b = 2, c = 3)
#' update_list <- list(a = 10, b = 20)
#' updated_list <- set_list(original_list, update_list)
#' print(updated_list) # List with a = 10, b = 20, c = NA
set_list <- function(original, list_to_set) {
  fields_updates <- names(list_to_set)
  fields_original <- names(original)
  for (key in fields_original) {
    if (key %in% fields_updates) {
      original[[key]] <- list_to_set[[key]]
    } else {
      original[[key]] <- NA
    }
  }
  return(original)
}

#' Update a List with Values from Another List, Excluding Specified Keys
#'
#' Update the original list with values from the updates list, excluding keys specified in exclude_keys.
#'
#' @param original The original list to update.
#' @param updates The list with update values.
#' @param exclude_keys A character vector of keys to exclude from updating.
#' @return The updated list.
#' @export
#' @examples
#' original_list <- list(a = 1, b = 2, c = 3)
#' updates_list <- list(a = 10, b = 20, d = 40)
#' exclude_keys <- c("b")
#' updated_list <- update_list(original_list, updates_list, exclude_keys)
#' print(updated_list) # List with a = 10, b = 2, c = 3, d = 40
update_list <- function(original, updates, exclude_keys) {
  update_keys <- names(updates)
  for (key in update_keys) {
    if (!(key %in% exclude_keys)) {
      original[[key]] <- updates[[key]]
    }
  }
  return(original)
}


## Example usage
list_structs <- list(list(name = "John", age = 30), list(name = "Jane", age = 25))
disp_list_of_structs(list_structs)

