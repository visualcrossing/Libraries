source("constants.R")
source("utils.R")

#' Weather Class to Interact with the Visual Crossing Weather API
#'
#' A class to fetch and manipulate weather data using the Visual Crossing Weather API.
#'
#' @field base_url Base URL of the API.
#' @field api_key API key for accessing the API.
#' @field weather_data Internal storage for weather data.
#'
#' @export
#' #' @examples
#' # Initialize the Weather object
#' weather <- Weather$new(api_key = "your_api_key_here")
#'
#' # Fetch weather data for a location
#' weather_data <- weather$fetch_weather_data("San Francisco", "2023-05-01", "2023-05-07")
#' print(weather_data)
#'
#' # Get index by datetime
#' idx <- weather$get_idx_from_datetimeArg(weather$weather_data, "2023-05-03")
#' print(idx)
#'
#' # Set item by datetime index
#' updated_data <- list(temperature = 75)
#' weather_data <- weather$set_item_by_datetimeIdx(weather$weather_data, idx, updated_data)
#' print(weather_data)
#'
#' # Update item by datetime index
#' more_data <- list(humidity = 50)
#' weather_data <- weather$update_item_by_datetimeIdx(weather$weather_data, idx, more_data)
#' print(weather_data)
Weather <- setRefClass(
  "Weather",
  fields = list(
    base_url = "character",
    api_key = "character",
    weather_data = "list"
  ),

  methods = list(
    initialize = function(api_key, base_url = "https://weather.visualcrossing.com/VisualCrossingWebServices/rest/services/timeline/") {
      # Initialize the Weather object with base URL and API key.
      .self$base_url <- base_url
      .self$api_key <- api_key
      .self$weather_data <- list()
    },

    #' Filters an item by its datetime value from a list of structs, each containing a 'datetime' field.
    #'
    #' @param src A list of lists (structs) with a 'datetime' field.
    #' @param datetimeArg The datetime value used for filtering, which can be a date string or an index.
    #' @return The index of the filtered item.
    #' @export
    get_idx_from_datetimeArg = function(src, datetimeArg) {
      idx <- 0
      if (is.character(datetimeArg)) {
        for (i in seq_along(src)) {
          if (src[[i]]$datetime == datetimeArg) {
            idx <- i
            return(idx)
          }
        }
      } else if (is.numeric(datetimeArg) && length(datetimeArg) == 1) {
        idx <- datetimeArg
      } else {
        stop('Invalid input datetime value for get_idx_from_datetimeArg: ', datetimeArg)
      }
      return(idx)
    },

    #' @description
    #' Sets an item's data by its datetime value in a list of structs based on the given datetime value.
    #'
    #' @param src A list of lists (structs) with a 'datetime' field.
    #' @param datetimeIdx The index of the item to update.
    #' @param data A list with new data to replace the old struct.
    #' @export
    set_item_by_datetimeIdx = function(src, datetimeIdx, data) {
      if (!is.list(data)) {
        stop('Invalid input data value for set_item_by_datetimeIdx: ', data)
      }
      if (is.numeric(datetimeIdx) && length(datetimeIdx) == 1) {
        data$datetime <- src[[datetimeIdx]]$datetime  # Ensure datetime is not changed
        src[[datetimeIdx]] <- data
      } else {
        stop('Invalid input datetime index for set_item_by_datetimeIdx: ', datetimeIdx)
      }
      return(src)
    },

    #' @description
    #' Updates an item's data by its datetime value in a list of structs based on the given datetime value.
    #'
    #' @param src A list of lists (structs) with a 'datetime' field.
    #' @param datetimeIdx The index of the item to update.
    #' @param data A list with new data to update the old struct.
    #' @export
    update_item_by_datetimeIdx = function(src, datetimeIdx, data) {
      if (!is.list(data)) {
        stop('Invalid input data value for update_item_by_datetimeIdx: ', data)
      }
      if (is.numeric(datetimeIdx) && length(datetimeIdx) == 1) {
        data$datetime <- src[[datetimeIdx]]$datetime  # Ensure datetime is not changed
        src[[datetimeIdx]] <- modifyList(src[[datetimeIdx]], data)
      } else {
        stop('Invalid input datetime index for update_item_by_datetimeIdx: ', datetimeIdx)
      }
      return(src)
    },

    #' @description
    #' Fetch weather data for a specified location and date range.
    #
    #' @param location Location for which weather data is requested.
    #' @param from_date Start date of the weather data period (in 'yyyy-MM-dd' format).
    #' @param to_date End date of the weather data period (in 'yyyy-MM-dd' format).
    #' @param unit_group Unit system for the weather data ('us', 'metric', 'uk', or 'base').
    #' @param include Data types to include (e.g., 'days', 'hours').
    #' @param elements Specific weather elements to retrieve.
    #' @return The weather data as a list.
    #' @export
    fetch_weather_data = function(location, from_date = "", to_date = "", unit_group = "us", include = "days", elements = "") {
      params <- list(unitGroup = unit_group, include = include, key = .self$api_key, elements = elements)
      url <- sprintf('%s%s/%s/%s', .self$base_url, location, from_date, to_date)

      response <- httr::GET(url, query = params)
      if (httr::status_code(response) == 200) {
        .self$weather_data <- httr::content(response, "parsed")
      } else {
        stop("Failed to fetch weather data: ", httr::status_code(response))
      }
      return(.self$weather_data)
    },

    #' @description
    #' Get the stored weather data.
    #'
    #' @param elements A character vector of elements to include in the returned data.
    #' @return A list containing the weather data filtered by elements if specified.
    #' @export
    get_weather_data = function(elements = character()) {
      tryCatch({
        if (length(elements) > 0) {
          weather_data <- extract_sublist_by_keys(.self$weather_data, elements)
        } else {
          weather_data <- .self$weather_data
        }
        return(weather_data)
      }, error = function(e) {
        message("Error accessing weather data: ", e$message)
        return(list())
      })
    },

    #' @description
    #' Set the internal weather data.
    #'
    #' @param data A list containing weather data to store.
    #' @export
    set_weather_data = function(data) {
      tryCatch({
        .self$weather_data <- data
      }, error = function(e) {
        stop(e)
      })
    },

    #' @description
    #' Get daily weather data, optionally filtered by elements.
    #'
    #' @param elements A character vector of elements to include in the returned data.
    #' @return A list of daily data, filtered by elements if specified.
    #' @export
    get_weather_daily_data = function(elements = character()) {
      tryCatch({
        days <- .self$weather_data$days
        if (length(elements) > 0) {
          lapply(days, function(day) extract_sublist_by_keys(day, elements))
        } else {
          return(days)
        }
      }, error = function(e) {
        message("Error accessing daily data: ", e$message)
        return(list())
      })
    },

    #' @description
    #' Set the daily weather data.
    #'
    #' @param daily_data A list of daily weather data.
    #' @export
    set_weather_daily_data = function(daily_data) {
      tryCatch({
        .self$weather_data$days <- daily_data
      }, error = function(e) {
        stop(e)
      })
    },

    #' @description
    #' Get hourly weather data for all days, optionally filtered by elements.
    #'
    #' @param elements A character vector of elements to include in the returned data.
    #' @return A list of hourly data, filtered by elements if specified.
    #' @export
    get_weather_hourly_data = function(elements = character()) {
      tryCatch({
        days <- .self$weather_data$days
        all_hours <- unlist(lapply(days, function(day) if (!is.null(day$hours)) day$hours else list()), recursive = FALSE)
        if (length(elements) > 0) {
          lapply(all_hours, function(hour) extract_sublist_by_keys(hour, elements))
        } else {
          return(all_hours)
        }
      }, error = function(e) {
        message("Error accessing hourly data: ", e$message)
        return(list())
      })
    },

    #' @description
    #' Retrieves the cost of the query from the weather data.
    #'
    #' @return The cost of the query if available, otherwise NA.
    #' @export
    get_queryCost = function() {
      if (!is.null(.self$weather_data$queryCost)) {
        return(.self$weather_data$queryCost)
      } else {
        return(NA)
      }
    },

    #' @description
    #' Sets the cost of the query in the weather data.
    #'
    #' @param value The new cost to be set for the query.
    #' @export
    set_queryCost = function(value) {
      tryCatch({
        .self$weather_data$queryCost <- value
      }, error = function(e) {
        stop(e)
      })
    },

    #' @description
    #' Retrieves the latitude from the weather data.
    #'
    #' @return The latitude if available, otherwise NA.
    #' @export
    get_latitude = function() {
      if (!is.null(.self$weather_data$latitude)) {
        return(.self$weather_data$latitude)
      } else {
        return(NA)
      }
    },

    #' @description
    #' Sets the latitude in the weather data.
    #'
    #' @param value The new latitude to be set.
    #' @export
    set_latitude = function(value) {
      tryCatch({
        .self$weather_data$latitude <- value
      }, error = function(e) {
        stop(e)
      })

    },

    #' @description
    #' Retrieves the longitude from the weather data.
    #'
    #' @return The longitude if available, otherwise NA.
    #' @export
    get_longitude = function() {
      if (!is.null(.self$weather_data$longitude)) {
        return(.self$weather_data$longitude)
      } else {
        return(NA)
      }
    },

    #' @description
    #' Sets the longitude in the weather data.
    #'
    #' @param value The new longitude to be set.
    #' @export
    set_longitude = function(value) {
      tryCatch({
        .self$weather_data$longitude <- value
      }, error = function(e) {
        stop(e)
      })
    },

    #' @description
    #' Retrieves the resolved address from the weather data.
    #'
    #' @return The resolved address if available, otherwise an empty string.
    #' @export
    get_resolvedAddress = function() {
      if (!is.null(.self$weather_data$resolvedAddress)) {
        return(.self$weather_data$resolvedAddress)
      } else {
        return("")
      }
    },

    #' @description
    #' Sets the resolved address in the weather data.
    #'
    #' @param value The new resolved address to be set.
    #' @export
    set_resolvedAddress = function(value) {
      tryCatch({
        .self$weather_data$resolvedAddress <- value
      }, error = function(e) {
        stop(e)
      })
    },

    #' @description
    #' Retrieves the address from the weather data.
    #'
    #' @return The address if available, otherwise an empty string.
    #' @export
    get_address = function() {
      if (!is.null(.self$weather_data$address)) {
        return(.self$weather_data$address)
      } else {
        return("")
      }
    },

    #' @description
    #' Sets the address in the weather data.
    #'
    #' @param value The new address to be set.
    #' @export
    set_address = function(value) {
      tryCatch({
        .self$weather_data$address <- value
      }, error = function(e) {
        stop(e)
      })
    },

    #' @description
    #' Retrieves the timezone from the weather data.
    #'
    #' @return The timezone if available, otherwise an empty string.
    #' @export
    get_timezone = function() {
      if (!is.null(.self$weather_data$timezone)) {
        return(.self$weather_data$timezone)
      } else {
        return("")
      }
    },

    #' @description
    #' Sets the timezone in the weather data.
    #'
    #' @param value The new timezone to be set.
    #' @export
    set_timezone = function(value) {
      tryCatch({
        .self$weather_data$timezone <- value
      }, error = function(e) {
        stop(e)
      })
    },

    #' @description
    #' Retrieves the timezone offset from the weather data.
    #'
    #' @return The timezone offset if available, otherwise NA.
    #' @export
    get_tzoffset = function() {
      if (!is.null(.self$weather_data$tzoffset)) {
        return(.self$weather_data$tzoffset)
      } else {
        return(NA)
      }
    },

    #' @description
    #' Sets the timezone offset in the weather data.
    #'
    #' @param value The new timezone offset to be set.
    #' @export
    set_tzoffset = function(value) {
      tryCatch({
        .self$weather_data$tzoffset <- value
      }, error = function(e) {
        stop(e)
      })
    },

    #' Retrieves the list of weather stations from the weather data.
    #'
    #' @return A list of weather stations if available, otherwise an empty list.
    #' @export
    get_stations = function() {
      if (!is.null(.self$weather_data$stations)) {
        return(.self$weather_data$stations)
      } else {
        return(list())
      }
    },

    #' @description
    #' Sets the list of weather stations in the weather data.
    #'
    #' @param value A list of weather stations to be set.
    #' @export
    set_stations = function(value) {
      tryCatch({
        .self$weather_data$stations <- value
      }, error = function(e) {
        stop(e)
      })
    },

    #' Retrieves a list of datetime objects representing each day's date from the weather data.
    #'
    #' @return A list of datetime objects parsed from the 'datetime' key of each day in the weather data.
    #' @export
    get_daily_datetimes = function() {
      tryCatch({
        days <- .self$weather_data$days
        daily_datetimes <- lapply(days, function(day) as.POSIXct(day$datetime, format = "%Y-%m-%d"))
        return(daily_datetimes)
      }, error = function(e) {
        message("Error accessing daily datetimes data: ", e$message)
        return(list())
      })
    },

    #' @description
    #' Retrieves a list of datetime objects representing each hour's datetime from the weather data.
    #'
    #' The method combines the 'datetime' from each day with the 'datetime' from each hour within that day.
    #'
    #' @return A list of datetime objects parsed from the 'datetime' keys of each day and hour in the weather data.
    #' @export
    get_hourly_datetimes = function() {
      tryCatch({
        days <- .self$weather_data$days
        hourly_datetimes <- list()
        for (day in days) {
          day_datetime <- as.POSIXct(day$datetime, format = "%Y-%m-%d")
          hours <- day$hours
          for (hour in hours) {
            hour_datetime <- as.POSIXct(hour$datetime, format = "%H:%M:%S")
            combined_datetime <- as.POSIXct(paste(format(day_datetime, "%Y-%m-%d"), format(hour_datetime, "%H:%M:%S")), format = "%Y-%m-%d %H:%M:%S")
            hourly_datetimes <- c(hourly_datetimes, combined_datetime)
          }
        }
        return(hourly_datetimes)
      }, error = function(e) {
        message("Error accessing hourly datetimes data: ", e$message)
        return(list())
      })
    },

    #' @description
    #' Retrieves weather data for a specific day based on a date string or index.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @param elements A character vector of elements to include in the returned data.
    #' @return A list containing the weather data for the specified day.
    #' @export
    get_data_on_day = function(day_info, elements = character()) {
      tryCatch({
        if (is.character(day_info)) {
          day_data <- NULL
          for (day in .self$weather_data$days) {
            if (day$datetime == day_info) {
              day_data <- day
              break
            }
          }
        } else if (is.numeric(day_info) && length(day_info) == 1) {
          day_data <- .self$weather_data$days[[day_info]]
        } else {
          stop("Invalid input value for day_info")
        }

        if (!is.null(elements) && length(elements) > 0) {
          day_data <- extract_sublist_by_keys(day_data, elements)
        }
        return(day_data)
      }, error = function(e) {
        message("Error accessing data on this day: ", e$message)
        return(list())
      })
    },

    #' @description
    #' Updates weather data for a specific day based on a date string or index.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @param data A list containing the new weather data to replace the existing day's data.
    #' @export
    set_data_on_day = function(day_info, data) {
      tryCatch({
        if (is.character(day_info)) {
          for (i in seq_along(.self$weather_data$days)) {
            if (.self$weather_data$days[[i]]$datetime == day_info) {
              .self$weather_data$days[[i]] <- data
              break
            }
          }
        } else if (is.numeric(day_info) && length(day_info) == 1) {
          .self$weather_data$days[[day_info]] <- data
        } else {
          stop("Invalid input value for day_info")
        }
      }, error = function(e) {
        stop(e)
      })
    },

    #' @description
    #' Retrieves the temperature for a specific day identified by date or index.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @return The temperature for the specified day.
    #' @export
    get_temp_on_day = function(day_info) {
      tryCatch({
        if (is.character(day_info)) {
          temp <- NULL
          for (day in .self$weather_data$days) {
            if (day$datetime == day_info) {
              temp <- day$temp
              break
            }
          }
        } else if (is.numeric(day_info) && length(day_info) == 1) {
          temp <- .self$weather_data$days[[day_info]]$temp
        } else {
          stop("Invalid input value for day_info")
        }
        return(temp)
      }, error = function(e) {
        message("Error accessing temperature data on this day: ", e$message)
        return(NULL)
      })
    },

    #' @description
    #' Sets the temperature for a specific day identified by date or index.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @param value The new temperature value to set.
    #' @export
    set_temp_on_day = function(day_info, value) {
      tryCatch({
        if (is.character(day_info)) {
          for (i in seq_along(.self$weather_data$days)) {
            if (.self$weather_data$days[[i]]$datetime == day_info) {
              .self$weather_data$days[[i]]$temp <- value
              break
            }
          }
        } else if (is.numeric(day_info) && length(day_info) == 1) {
          .self$weather_data$days[[day_info]]$temp <- value
        } else {
          stop("Invalid input value for day_info")
        }
      }, error = function(e) {
        stop(e)
      })
    },

    #' @description
    #' Retrieves the maximum temperature for a specific day identified by date or index.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @return The maximum temperature for the specified day.
    #' @export
    get_tempmax_on_day = function(day_info) {
      tryCatch({
        if (is.character(day_info)) {
          tempmax <- NULL
          for (day in .self$weather_data$days) {
            if (day$datetime == day_info) {
              tempmax <- day$tempmax
              break
            }
          }
        } else if (is.numeric(day_info) && length(day_info) == 1) {
          tempmax <- .self$weather_data$days[[day_info]]$tempmax
        } else {
          stop("Invalid input value for day_info")
        }
        return(tempmax)
      }, error = function(e) {
        message("Error accessing maximum temperature data on this day: ", e$message)
        return(NULL)
      })
    },

    #' @description
    #' Sets the maximum temperature for a specific day identified by date or index.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @param value The new maximum temperature value to set.
    #' @export
    set_tempmax_on_day = function(day_info, value) {
      tryCatch({
        if (is.character(day_info)) {
          for (i in seq_along(.self$weather_data$days)) {
            if (.self$weather_data$days[[i]]$datetime == day_info) {
              .self$weather_data$days[[i]]$tempmax <- value
              break
            }
          }
        } else if (is.numeric(day_info) && length(day_info) == 1) {
          .self$weather_data$days[[day_info]]$tempmax <- value
        } else {
          stop("Invalid input value for day_info")
        }
      }, error = function(e) {
        stop(e)
      })
    },

    #' @description
    #' Retrieves the minimum temperature for a specific day identified by date or index.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @return The minimum temperature for the specified day.
    #' @export
    get_tempmin_on_day = function(day_info) {
      tryCatch({
        if (is.character(day_info)) {
          tempmin <- NULL
          for (day in .self$weather_data$days) {
            if (day$datetime == day_info) {
              tempmin <- day$tempmin
              break
            }
          }
        } else if (is.numeric(day_info) && length(day_info) == 1) {
          tempmin <- .self$weather_data$days[[day_info]]$tempmin
        } else {
          stop("Invalid input value for day_info")
        }
        return(tempmin)
      }, error = function(e) {
        message("Error accessing minimum temperature data on this day: ", e$message)
        return(NULL)
      })
    },

    #' @description
    #' Sets the minimum temperature for a specific day identified by date or index.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @param value The new minimum temperature value to set.
    #' @export
    set_tempmin_on_day = function(day_info, value) {
      tryCatch({
        if (is.character(day_info)) {
          for (i in seq_along(.self$weather_data$days)) {
            if (.self$weather_data$days[[i]]$datetime == day_info) {
              .self$weather_data$days[[i]]$tempmin <- value
              break
            }
          }
        } else if (is.numeric(day_info) && length(day_info) == 1) {
          .self$weather_data$days[[day_info]]$tempmin <- value
        } else {
          stop("Invalid input value for day_info")
        }
      }, error = function(e) {
        stop(e)
      })
    },

    #' @description
    #' Retrieves the 'feels like' temperature for a specific day identified by date or index.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @return The 'feels like' temperature for the specified day.
    #' @export
    get_feelslike_on_day = function(day_info) {
      tryCatch({
        if (is.character(day_info)) {
          feelslike <- NULL
          for (day in .self$weather_data$days) {
            if (day$datetime == day_info) {
              feelslike <- day$feelslike
              break
            }
          }
        } else if (is.numeric(day_info) && length(day_info) == 1) {
          feelslike <- .self$weather_data$days[[day_info]]$feelslike
        } else {
          stop("Invalid input value for day_info")
        }
        return(feelslike)
      }, error = function(e) {
        message("Error accessing 'feels like' temperature data on this day: ", e$message)
        return(NULL)
      })
    },

    #' @description
    #' Sets the 'feels like' temperature for a specific day identified by date or index.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @param value The new 'feels like' temperature value to set.
    #' @export
    set_feelslike_on_day = function(day_info, value) {
      tryCatch({
        if (is.character(day_info)) {
          for (i in seq_along(.self$weather_data$days)) {
            if (.self$weather_data$days[[i]]$datetime == day_info) {
              .self$weather_data$days[[i]]$feelslike <- value
              break
            }
          }
        } else if (is.numeric(day_info) && length(day_info) == 1) {
          .self$weather_data$days[[day_info]]$feelslike <- value
        } else {
          stop("Invalid input value for day_info")
        }
      }, error = function(e) {
        stop(e)
      })
    },

    #' @description
    #' Retrieves the maximum 'feels like' temperature for a specific day identified by date or index.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @return The maximum 'feels like' temperature for the specified day.
    #' @export
    get_feelslikemax_on_day = function(day_info) {
      tryCatch({
        if (is.character(day_info)) {
          feelslikemax <- NULL
          for (day in .self$weather_data$days) {
            if (day$datetime == day_info) {
              feelslikemax <- day$feelslikemax
              break
            }
          }
        } else if (is.numeric(day_info) && length(day_info) == 1) {
          feelslikemax <- .self$weather_data$days[[day_info]]$feelslikemax
        } else {
          stop("Invalid input value for day_info")
        }
        return(feelslikemax)
      }, error = function(e) {
        message("Error accessing 'feels like max' temperature data on this day: ", e$message)
        return(NULL)
      })
    },

    #' @description
    #' Sets the maximum 'feels like' temperature for a specific day identified by date or index.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @param value The new maximum 'feels like' temperature value to set.
    #' @export
    set_feelslikemax_on_day = function(day_info, value) {
      tryCatch({
        if (is.character(day_info)) {
          for (i in seq_along(.self$weather_data$days)) {
            if (.self$weather_data$days[[i]]$datetime == day_info) {
              .self$weather_data$days[[i]]$feelslikemax <- value
              break
            }
          }
        } else if (is.numeric(day_info) && length(day_info) == 1) {
          .self$weather_data$days[[day_info]]$feelslikemax <- value
        } else {
          stop("Invalid input value for day_info")
        }
      }, error = function(e) {
        stop(e)
      })
    },

    #' @description
    #' Retrieves the minimum 'feels like' temperature for a specific day identified by date or index.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @return The minimum 'feels like' temperature for the specified day.
    #' @export
    get_feelslikemin_on_day = function(day_info) {
      tryCatch({
        if (is.character(day_info)) {
          feelslikemin <- NULL
          for (day in .self$weather_data$days) {
            if (day$datetime == day_info) {
              feelslikemin <- day$feelslikemin
              break
            }
          }
        } else if (is.numeric(day_info) && length(day_info) == 1) {
          feelslikemin <- .self$weather_data$days[[day_info]]$feelslikemin
        } else {
          stop("Invalid input value for day_info")
        }
        return(feelslikemin)
      }, error = function(e) {
        message("Error accessing 'feels like min' temperature data on this day: ", e$message)
        return(NULL)
      })
    },

    #' @description
    #' Sets the minimum 'feels like' temperature for a specific day identified by date or index.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @param value The new minimum 'feels like' temperature value to set.
    #' @export
    set_feelslikemin_on_day = function(day_info, value) {
      tryCatch({
        if (is.character(day_info)) {
          for (i in seq_along(.self$weather_data$days)) {
            if (.self$weather_data$days[[i]]$datetime == day_info) {
              .self$weather_data$days[[i]]$feelslikemin <- value
              break
            }
          }
        } else if (is.numeric(day_info) && length(day_info) == 1) {
          .self$weather_data$days[[day_info]]$feelslikemin <- value
        } else {
          stop("Invalid input value for day_info")
        }
      }, error = function(e) {
        stop(e)
      })
    },

    #' @description
    #' Retrieves the dew point for a specific day identified by date or index.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @return The dew point for the specified day.
    #' @export
    get_dew_on_day = function(day_info) {
      tryCatch({
        if (is.character(day_info)) {
          dew <- NULL
          for (day in .self$weather_data$days) {
            if (day$datetime == day_info) {
              dew <- day$dew
              break
            }
          }
        } else if (is.numeric(day_info) && length(day_info) == 1) {
          dew <- .self$weather_data$days[[day_info]]$dew
        } else {
          stop("Invalid input value for day_info")
        }
        return(dew)
      }, error = function(e) {
        message("Error accessing dew point data on this day: ", e$message)
        return(NULL)
      })
    },

    #' @description
    #' Sets the dew point for a specific day identified by date or index.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @param value The new dew point value to set.
    #' @export
    set_dew_on_day = function(day_info, value) {
      tryCatch({
        if (is.character(day_info)) {
          for (i in seq_along(.self$weather_data$days)) {
            if (.self$weather_data$days[[i]]$datetime == day_info) {
              .self$weather_data$days[[i]]$dew <- value
              break
            }
          }
        } else if (is.numeric(day_info) && length(day_info) == 1) {
          .self$weather_data$days[[day_info]]$dew <- value
        } else {
          stop("Invalid input value for day_info")
        }
      }, error = function(e) {
        stop(e)
      })
    },

    #' @description
    #' Retrieves the humidity percentage for a specific day identified by date or index.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @return The humidity percentage for the specified day.
    #' @export
    get_humidity_on_day = function(day_info) {
      tryCatch({
        if (is.character(day_info)) {
          humidity <- NULL
          for (day in .self$weather_data$days) {
            if (day$datetime == day_info) {
              humidity <- day$humidity
              break
            }
          }
        } else if (is.numeric(day_info) && length(day_info) == 1) {
          humidity <- .self$weather_data$days[[day_info]]$humidity
        } else {
          stop("Invalid input value for day_info")
        }
        return9humidity)
      }, error = function(e) {
        message("Error accessing humidity data on this day: ", e$message)
        return(NULL)
      })
    },

    #' @description
    #' Sets the humidity percentage for a specific day identified by date or index.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @param value The new humidity percentage value to set.
    #' @export
    set_humidity_on_day = function(day_info, value) {
      tryCatch({
        if (is.character(day_info)) {
          for (i in seq_along(.self$weather_data$days)) {
            if (.self$weather_data$days[[i]]$datetime == day_info) {
              .self$weather_data$days[[i]]$humidity <- value
              break
            }
          }
        } else if (is.numeric(day_info) && length(day_info) == 1) {
          .self$weather_data$days[[day_info]]$humidity <- value
        } else {
          stop("Invalid input value for day_info")
        }
      }, error = function(e) {
        stop(e)
      })
    },

    #' @description
    #' Retrieves the precipitation amount for a specific day identified by date or index.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @return The precipitation amount for the specified day.
    #' @examples
    #' weather <- Weather$new(api_key = "your_api_key")
    #' weather$fetch_weather_data("New York", "2023-01-01", "2023-01-07")
    #' weather$get_precip_on_day("2023-01-01")
    get_precip_on_day = function(day_info) {
      tryCatch({
        if (is.character(day_info)) {
          precip <- NULL
          for (day in .self$weather_data$days) {
            if (day$datetime == day_info) {
              precip <- day$precip
              break
            }
          }
        } else if (is.numeric(day_info) && length(day_info) == 1) {
          precip <- .self$weather_data$days[[day_info]]$precip
        } else {
          stop("Invalid input value for day_info")
        }
        return(precip)
      }, error = function(e) {
        message("Error accessing precipitation data on this day: ", e$message)
        return(NULL)
      })
    },

    #' @description
    #' Sets the precipitation amount for a specific day identified by date or index.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @param value The new precipitation amount value to set.
    #' @examples
    #' weather <- Weather$new(api_key = "your_api_key")
    #' weather$fetch_weather_data("New York", "2023-01-01", "2023-01-07")
    #' weather$set_precip_on_day("2023-01-01", 5.0)
    set_precip_on_day = function(day_info, value) {
      tryCatch({
        if (is.character(day_info)) {
          for (i in seq_along(.self$weather_data$days)) {
            if (.self$weather_data$days[[i]]$datetime == day_info) {
              .self$weather_data$days[[i]]$precip <- value
              break
            }
          }
        } else if (is.numeric(day_info) && length(day_info) == 1) {
          .self$weather_data$days[[day_info]]$precip <- value
        } else {
          stop("Invalid input value for day_info")
        }
      }, error = function(e) {
        stop(e)
      })
    },

    #' @description
    #' Retrieves the probability of precipitation for a specific day identified by date or index.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @return The probability of precipitation for the specified day.
    #' @examples
    #' weather <- Weather$new(api_key = "your_api_key")
    #' weather$fetch_weather_data("New York", "2023-01-01", "2023-01-07")
    #' weather$get_precipprob_on_day("2023-01-01")
    get_precipprob_on_day = function(day_info) {
      tryCatch({
        if (is.character(day_info)) {
          precipprob <- NULL
          for (day in .self$weather_data$days) {
            if (day$datetime == day_info) {
              precipprob <- day$precipprob
              break
            }
          }
        } else if (is.numeric(day_info) && length(day_info) == 1) {
          precipprob <- .self$weather_data$days[[day_info]]$precipprob
        } else {
          stop("Invalid input value for day_info")
        }
        return(precipprob)
      }, error = function(e) {
        message("Error accessing precipitation probability data on this day: ", e$message)
        return(NULL)
      })
    },

    #' @description
    #' Sets the probability of precipitation for a specific day identified by date or index.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @param value The new probability of precipitation value to set.
    #' @examples
    #' weather <- Weather$new(api_key = "your_api_key")
    #' weather$fetch_weather_data("New York", "2023-01-01", "2023-01-07")
    #' weather$set_precipprob_on_day("2023-01-01", 50)
    set_precipprob_on_day = function(day_info, value) {
      tryCatch({
        if (is.character(day_info)) {
          for (i in seq_along(.self$weather_data$days)) {
            if (.self$weather_data$days[[i]]$datetime == day_info) {
              .self$weather_data$days[[i]]$precipprob <- value
              break
            }
          }
        } else if (is.numeric(day_info) && length(day_info) == 1) {
          .self$weather_data$days[[day_info]]$precipprob <- value
        } else {
          stop("Invalid input value for day_info")
        }
      }, error = function(e) {
        stop(e)
      })
    },

    #' @description
    #' Retrieves the precipitation coverage for a specific day identified by date or index.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @return The precipitation coverage for the specified day.
    #' @examples
    #' weather <- Weather$new(api_key = "your_api_key")
    #' weather$fetch_weather_data("New York", "2023-01-01", "2023-01-07")
    #' weather$get_precipcover_on_day("2023-01-01")
    get_precipcover_on_day = function(day_info) {
      tryCatch({
        if (is.character(day_info)) {
          precipcover <- NULL
          for (day in .self$weather_data$days) {
            if (day$datetime == day_info) {
              precipcover <- day$precipcover
              break
            }
          }
        } else if (is.numeric(day_info) && length(day_info) == 1) {
          precipcover <- .self$weather_data$days[[day_info]]$precipcover
        } else {
          stop("Invalid input value for day_info")
        }
        return(precipcover)
      }, error = function(e) {
        message("Error accessing precipitation coverage data on this day: ", e$message)
        return(NULL)
      })
    },

    #' @description
    #' Sets the precipitation coverage for a specific day identified by date or index.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @param value The new precipitation coverage value to set.
    #' @export
    set_precipcover_on_day = function(day_info, value) {
      tryCatch({
        if (is.character(day_info)) {
          for (i in seq_along(.self$weather_data$days)) {
            if (.self$weather_data$days[[i]]$datetime == day_info) {
              .self$weather_data$days[[i]]$precipcover <- value
              break
            }
          }
        } else if (is.numeric(day_info) && length(day_info) == 1) {
          .self$weather_data$days[[day_info]]$precipcover <- value
        } else {
          stop("Invalid input value for day_info")
        }
      }, error = function(e) {
        stop(e)
      })
    },

    #' @description
    #' Retrieves the type of precipitation for a specific day identified by date or index.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @return The type of precipitation for the specified day.
    #' @export
    get_preciptype_on_day = function(day_info) {
      tryCatch({
        if (is.character(day_info)) {
          preciptype <- NULL
          for (day in .self$weather_data$days) {
            if (day$datetime == day_info) {
              preciptype <- day$preciptype
              break
            }
          }
        } else if (is.numeric(day_info) && length(day_info) == 1) {
          preciptype <- .self$weather_data$days[[day_info]]$preciptype
        } else {
          stop("Invalid input value for day_info")
        }
        return(preciptype)
      }, error = function(e) {
        message("Error accessing precipitation type data on this day: ", e$message)
        return(NULL)
      })
    },

    #' @description
    #' Sets the type of precipitation for a specific day identified by date or index.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @param value The new type of precipitation value to set.
    #' @export
    set_preciptype_on_day = function(day_info, value) {
      tryCatch({
        if (is.character(day_info)) {
          for (i in seq_along(.self$weather_data$days)) {
            if (.self$weather_data$days[[i]]$datetime == day_info) {
              .self$weather_data$days[[i]]$preciptype <- value
              break
            }
          }
        } else if (is.numeric(day_info) && length(day_info) == 1) {
          .self$weather_data$days[[day_info]]$preciptype <- value
        } else {
          stop("Invalid input value for day_info")
        }
      }, error = function(e) {
        stop(e)
      })
    },

    #' @description
    #' Retrieves the snowfall amount for a specific day identified by date or index.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @return The snowfall amount for the specified day.
    #' @export
    get_snow_on_day = function(day_info) {
      tryCatch({
        if (is.character(day_info)) {
          snow <- NULL
          for (day in .self$weather_data$days) {
            if (day$datetime == day_info) {
              snow <- day$snow
              break
            }
          }
        } else if (is.numeric(day_info) && length(day_info) == 1) {
          snow <- .self$weather_data$days[[day_info]]$snow
        } else {
          stop("Invalid input value for day_info")
        }
        return(snow)
      }, error = function(e) {
        message("Error accessing snow data on this day: ", e$message)
        return(NULL)
      })
    },

    #' @description
    #' Sets the snowfall amount for a specific day identified by date or index.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @param value The new snowfall amount to set.
    #' @export
    set_snow_on_day = function(day_info, value) {
      tryCatch({
        if (is.character(day_info)) {
          for (i in seq_along(.self$weather_data$days)) {
            if (.self$weather_data$days[[i]]$datetime == day_info) {
              .self$weather_data$days[[i]]$snow <- value
              break
            }
          }
        } else if (is.numeric(day_info) && length(day_info) == 1) {
          .self$weather_data$days[[day_info]]$snow <- value
        } else {
          stop("Invalid input value for day_info")
        }
      }, error = function(e) {
        stop(e)
      })
    },

    #' @description
    #' Retrieves the snow depth for a specific day identified by date or index.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @return The snow depth for the specified day.
    #' @export
    get_snowdepth_on_day = function(day_info) {
      tryCatch({
        if (is.character(day_info)) {
          snowdepth <- NULL
          for (day in .self$weather_data$days) {
            if (day$datetime == day_info) {
              snowdepth <- day$snowdepth
              break
            }
          }
        } else if (is.numeric(day_info) && length(day_info) == 1) {
          snowdepth <- .self$weather_data$days[[day_info]]$snowdepth
        } else {
          stop("Invalid input value for day_info")
        }
        return(snowdepth)
      }, error = function(e) {
        message("Error accessing snow depth data on this day: ", e$message)
        return(NULL)
      })
    },

    #' @description
    #' Sets the snow depth for a specific day identified by date or index.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @param value The new snow depth value to set.
    #' @export
    set_snowdepth_on_day = function(day_info, value) {
      tryCatch({
        if (is.character(day_info)) {
          for (i in seq_along(.self$weather_data$days)) {
            if (.self$weather_data$days[[i]]$datetime == day_info) {
              .self$weather_data$days[[i]]$snowdepth <- value
              break
            }
          }
        } else if (is.numeric(day_info) && length(day_info) == 1) {
          .self$weather_data$days[[day_info]]$snowdepth <- value
        } else {
          stop("Invalid input value for day_info")
        }
      }, error = function(e) {
        stop(e)
      })
    },

    #' @description
    #' Retrieves the wind gust value for a specific day identified by date or index.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @return The wind gust value for the specified day.
    #' @export
    get_windgust_on_day = function(day_info) {
      tryCatch({
        if (is.character(day_info)) {
          windgust <- NULL
          for (day in .self$weather_data$days) {
            if (day$datetime == day_info) {
              windgust <- day$windgust
              break
            }
          }
        } else if (is.numeric(day_info) && length(day_info) == 1) {
          windgust <- .self$weather_data$days[[day_info]]$windgust
        } else {
          stop("Invalid input value for day_info")
        }
        return(windgust)
      }, error = function(e) {
        message("Error accessing wind gust data on this day: ", e$message)
        return(NULL)
      })
    },

    #' @description
    #' Sets the wind gust value for a specific day identified by date or index.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @param value The new wind gust value to set.
    #' @export
    set_windgust_on_day = function(day_info, value) {
      tryCatch({
        if (is.character(day_info)) {
          for (i in seq_along(.self$weather_data$days)) {
            if (.self$weather_data$days[[i]]$datetime == day_info) {
              .self$weather_data$days[[i]]$windgust <- value
              break
            }
          }
        } else if (is.numeric(day_info) && length(day_info) == 1) {
          .self$weather_data$days[[day_info]]$windgust <- value
        } else {
          stop("Invalid input value for day_info")
        }
      }, error = function(e) {
        stop(e)
      })
    },

    #' @description
    #' Retrieves the wind speed for a specific day identified by date or index.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @return The wind speed for the specified day.
    #' @export
    get_windspeed_on_day = function(day_info) {
      tryCatch({
        if (is.character(day_info)) {
          windspeed <- NULL
          for (day in .self$weather_data$days) {
            if (day$datetime == day_info) {
              windspeed <- day$windspeed
              break
            }
          }
        } else if (is.numeric(day_info) && length(day_info) == 1) {
          windspeed <- .self$weather_data$days[[day_info]]$windspeed
        } else {
          stop("Invalid input value for day_info")
        }
        return(windspeed)
      }, error = function(e) {
        message("Error accessing wind speed data on this day: ", e$message)
        return(NULL)
      })
    },

    #' @description
    #' Sets the wind speed for a specific day identified by date or index.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @param value The new wind speed value to set.
    #' @export
    set_windspeed_on_day = function(day_info, value) {
      tryCatch({
        if (is.character(day_info)) {
          for (i in seq_along(.self$weather_data$days)) {
            if (.self$weather_data$days[[i]]$datetime == day_info) {
              .self$weather_data$days[[i]]$windspeed <- value
              break
            }
          }
        } else if (is.numeric(day_info) && length(day_info) == 1) {
          .self$weather_data$days[[day_info]]$windspeed <- value
        } else {
          stop("Invalid input value for day_info")
        }
      }, error = function(e) {
        stop(e)
      })
    },

    #' @description
    #' Retrieves the wind direction for a specific day identified by date or index.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @return The wind direction for the specified day.
    #' @export
    get_winddir_on_day = function(day_info) {
      tryCatch({
        if (is.character(day_info)) {
          winddir <- NULL
          for (day in .self$weather_data$days) {
            if (day$datetime == day_info) {
              winddir <- day$winddir
              break
            }
          }
        } else if (is.numeric(day_info) && length(day_info) == 1) {
          winddir <- .self$weather_data$days[[day_info]]$winddir
        } else {
          stop("Invalid input value for day_info")
        }
        return(winddir)
      }, error = function(e) {
        message("Error accessing wind direction data on this day: ", e$message)
        return(NULL)
      })
    },

    #' @description
    #' Sets the wind direction for a specific day identified by date or index.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @param value The new wind direction value to set.
    #' @export
    set_winddir_on_day = function(day_info, value) {
      tryCatch({
        if (is.character(day_info)) {
          for (i in seq_along(.self$weather_data$days)) {
            if (.self$weather_data$days[[i]]$datetime == day_info) {
              .self$weather_data$days[[i]]$winddir <- value
              break
            }
          }
        } else if (is.numeric(day_info) && length(day_info) == 1) {
          .self$weather_data$days[[day_info]]$winddir <- value
        } else {
          stop("Invalid input value for day_info")
        }
      }, error = function(e) {
        stop(e)
      })
    },

    #' @description
    #' Retrieves the atmospheric pressure for a specific day identified by date or index.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @return The atmospheric pressure for the specified day.
    #' @export
    get_pressure_on_day = function(day_info) {
      tryCatch({
        if (is.character(day_info)) {
          pressure <- NULL
          for (day in .self$weather_data$days) {
            if (day$datetime == day_info) {
              pressure <- day$pressure
              break
            }
          }
        } else if (is.numeric(day_info) && length(day_info) == 1) {
          pressure <- .self$weather_data$days[[day_info]]$pressure
        } else {
          stop("Invalid input value for day_info")
        }
        return(pressure)
      }, error = function(e) {
        message("Error accessing pressure data on this day: ", e$message)
        return(NULL)
      })
    },

    #' @description
    #' Sets the atmospheric pressure for a specific day identified by date or index.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @param value The new pressure value to set.
    #' @export
    set_pressure_on_day = function(day_info, value) {
      tryCatch({
        if (is.character(day_info)) {
          for (i in seq_along(.self$weather_data$days)) {
            if (.self$weather_data$days[[i]]$datetime == day_info) {
              .self$weather_data$days[[i]]$pressure <- value
              break
            }
          }
        } else if (is.numeric(day_info) && length(day_info) == 1) {
          .self$weather_data$days[[day_info]]$pressure <- value
        } else {
          stop("Invalid input value for day_info")
        }
      }, error = function(e) {
        stop(e)
      })
    },

    #' @description
    #' Retrieves the cloud cover percentage for a specific day identified by date or index.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @return The cloud cover percentage for the specified day.
    #' @export
    get_cloudcover_on_day = function(day_info) {
      tryCatch({
        if (is.character(day_info)) {
          cloudcover <- NULL
          for (day in .self$weather_data$days) {
            if (day$datetime == day_info) {
              cloudcover <- day$cloudcover
              break
            }
          }
        } else if (is.numeric(day_info) && length(day_info) == 1) {
          cloudcover <- .self$weather_data$days[[day_info]]$cloudcover
        } else {
          stop("Invalid input value for day_info")
        }
        return(cloudcover)
      }, error = function(e) {
        message("Error accessing cloud cover data on this day: ", e$message)
        return(NULL)
      })
    },

    #' @description
    #' Sets the cloud cover percentage for a specific day identified by date or index.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @param value The new cloud cover percentage value to set.
    #' @export
    set_cloudcover_on_day = function(day_info, value) {
      tryCatch({
        if (is.character(day_info)) {
          for (i in seq_along(.self$weather_data$days)) {
            if (.self$weather_data$days[[i]]$datetime == day_info) {
              .self$weather_data$days[[i]]$cloudcover <- value
              break
            }
          }
        } else if (is.numeric(day_info) && length(day_info) == 1) {
          .self$weather_data$days[[day_info]]$cloudcover <- value
        } else {
          stop("Invalid input value for day_info")
        }
      }, error = function(e) {
        stop(e)
      })
    },

    #' @description
    #' Retrieves the visibility distance for a specific day identified by date or index.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @return The visibility distance for the specified day.
    #' @export
    get_visibility_on_day = function(day_info) {
      tryCatch({
        if (is.character(day_info)) {
          visibility <- NULL
          for (day in .self$weather_data$days) {
            if (day$datetime == day_info) {
              visibility <- day$visibility
              break
            }
          }
        } else if (is.numeric(day_info) && length(day_info) == 1) {
          visibility <- .self$weather_data$days[[day_info]]$visibility
        } else {
          stop("Invalid input value for day_info")
        }
        return(visibility)
      }, error = function(e) {
        message("Error accessing visibility data on this day: ", e$message)
        return(NULL)
      })
    },

    #' @description
    #' Sets the visibility distance for a specific day identified by date or index.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @param value The new visibility distance to set.
    #' @export
    set_visibility_on_day = function(day_info, value) {
      tryCatch({
        if (is.character(day_info)) {
          for (i in seq_along(.self$weather_data$days)) {
            if (.self$weather_data$days[[i]]$datetime == day_info) {
              .self$weather_data$days[[i]]$visibility <- value
              break
            }
          }
        } else if (is.numeric(day_info) && length(day_info) == 1) {
          .self$weather_data$days[[day_info]]$visibility <- value
        } else {
          stop("Invalid input value for day_info")
        }
      }, error = function(e) {
        stop(e)
      })
    },

    #' @description
    #' Retrieves the solar radiation level for a specific day identified by date or index.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @return The solar radiation level for the specified day.
    #' @export
    get_solarradiation_on_day = function(day_info) {
      tryCatch({
        if (is.character(day_info)) {
          solarradiation <- NULL
          for (day in .self$weather_data$days) {
            if (day$datetime == day_info) {
              solarradiation <- day$solarradiation
              break
            }
          }
        } else if (is.numeric(day_info) && length(day_info) == 1) {
          solarradiation <- .self$weather_data$days[[day_info]]$solarradiation
        } else {
          stop("Invalid input value for day_info")
        }
        return(solarradiation)
      }, error = function(e) {
        message("Error accessing solar radiation data on this day: ", e$message)
        return(NULL)
      })
    },

    #' @description
    #' Sets the solar radiation level for a specific day identified by date or index.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @param value The new solar radiation level to set.
    #' @export
    set_solarradiation_on_day = function(day_info, value) {
      tryCatch({
        if (is.character(day_info)) {
          for (i in seq_along(.self$weather_data$days)) {
            if (.self$weather_data$days[[i]]$datetime == day_info) {
              .self$weather_data$days[[i]]$solarradiation <- value
              break
            }
          }
        } else if (is.numeric(day_info) && length(day_info) == 1) {
          .self$weather_data$days[[day_info]]$solarradiation <- value
        } else {
          stop("Invalid input value for day_info")
        }
      }, error = function(e) {
        stop(e)
      })
    },

    #' @description
    #' Retrieves the solar energy generated on a specific day identified by date or index.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @return The solar energy generated on the specified day.
    #' @export
    get_solarenergy_on_day = function(day_info) {
      tryCatch({
        if (is.character(day_info)) {
          solarenergy <- NULL
          for (day in .self$weather_data$days) {
            if (day$datetime == day_info) {
              solarenergy <- day$solarenergy
              break
            }
          }
        } else if (is.numeric(day_info) && length(day_info) == 1) {
          solarenergy <- .self$weather_data$days[[day_info]]$solarenergy
        } else {
          stop("Invalid input value for day_info")
        }
        return(solarenergy)
      }, error = function(e) {
        message("Error accessing solar energy data on this day: ", e$message)
        return(NULL)
      })
    },

    #' @description
    #' Sets the solar energy level for a specific day identified by date or index.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @param value The new solar energy level to set.
    #' @export
    set_solarenergy_on_day = function(day_info, value) {
      tryCatch({
        if (is.character(day_info)) {
          for (i in seq_along(.self$weather_data$days)) {
            if (.self$weather_data$days[[i]]$datetime == day_info) {
              .self$weather_data$days[[i]]$solarenergy <- value
              break
            }
          }
        } else if (is.numeric(day_info) && length(day_info) == 1) {
          .self$weather_data$days[[day_info]]$solarenergy <- value
        } else {
          stop("Invalid input value for day_info")
        }
      }, error = function(e) {
        stop(e)
      })
    },

    #' @description
    #' Retrieves the UV index for a specific day identified by date or index.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @return The UV index for the specified day.
    #' @export
    get_uvindex_on_day = function(day_info) {
      tryCatch({
        if (is.character(day_info)) {
          uvindex <- NULL
          for (day in .self$weather_data$days) {
            if (day$datetime == day_info) {
              uvindex <- day$uvindex
              break
            }
          }
        } else if (is.numeric(day_info) && length(day_info) == 1) {
          uvindex <- .self$weather_data$days[[day_info]]$uvindex
        } else {
          stop("Invalid input value for day_info")
        }
        return(uvindex)
      }, error = function(e) {
        message("Error accessing UV index data on this day: ", e$message)
        return(NULL)
      })
    },

    #' @description
    #' Sets the UV index for a specific day identified by date or index.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @param value The new UV index value to set.
    #' @export
    set_uvindex_on_day = function(day_info, value) {
      tryCatch({
        if (is.character(day_info)) {
          for (i in seq_along(.self$weather_data$days)) {
            if (.self$weather_data$days[[i]]$datetime == day_info) {
              .self$weather_data$days[[i]]$uvindex <- value
              break
            }
          }
        } else if (is.numeric(day_info) && length(day_info) == 1) {
          .self$weather_data$days[[day_info]]$uvindex <- value
        } else {
          stop("Invalid input value for day_info")
        }
      }, error = function(e) {
        stop(e)
      })
    },

    #' @description
    #' Retrieves the severe weather risk level for a specific day identified by date or index.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @return The severe weather risk level for the specified day.
    #' @export
    get_severerisk_on_day = function(day_info) {
      tryCatch({
        if (is.character(day_info)) {
          severerisk <- NULL
          for (day in .self$weather_data$days) {
            if (day$datetime == day_info) {
              severerisk <- day$severerisk
              break
            }
          }
        } else if (is.numeric(day_info) && length(day_info) == 1) {
          severerisk <- .self$weather_data$days[[day_info]]$severerisk
        } else {
          stop("Invalid input value for day_info")
        }
        return(severerisk)
      }, error = function(e) {
        message("Error accessing severe risk data on this day: ", e$message)
        return(NULL)
      })
    },

    #' @description
    #' Sets the severe weather risk level for a specific day identified by date or index.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @param value The new severe weather risk level to set.
    #' @export
    set_severerisk_on_day = function(day_info, value) {
      tryCatch({
        if (is.character(day_info)) {
          for (i in seq_along(.self$weather_data$days)) {
            if (.self$weather_data$days[[i]]$datetime == day_info) {
              .self$weather_data$days[[i]]$severerisk <- value
              break
            }
          }
        } else if (is.numeric(day_info) && length(day_info) == 1) {
          .self$weather_data$days[[day_info]]$severerisk <- value
        } else {
          stop("Invalid input value for day_info")
        }
      }, error = function(e) {
        stop(e)
      })
    },

    #' @description
    #' Retrieves the sunrise time for a specific day identified by date or index.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @return The sunrise time for the specified day.
    #' @export
    get_sunrise_on_day = function(day_info) {
      tryCatch({
        if (is.character(day_info)) {
          sunrise <- NULL
          for (day in .self$weather_data$days) {
            if (day$datetime == day_info) {
              sunrise <- day$sunrise
              break
            }
          }
        } else if (is.numeric(day_info) && length(day_info) == 1) {
          sunrise <- .self$weather_data$days[[day_info]]$sunrise
        } else {
          stop("Invalid input value for day_info")
        }
        return(sunrise)
      }, error = function(e) {
        message("Error accessing sunrise data on this day: ", e$message)
        return(NULL)
      })
    },

    #' @description
    #' Sets the sunrise time for a specific day identified by date or index.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @param value The new sunrise time value to set.
    #' @export
    set_sunrise_on_day = function(day_info, value) {
      tryCatch({
        if (is.character(day_info)) {
          for (i in seq_along(.self$weather_data$days)) {
            if (.self$weather_data$days[[i]]$datetime == day_info) {
              .self$weather_data$days[[i]]$sunrise <- value
              break
            }
          }
        } else if (is.numeric(day_info) && length(day_info) == 1) {
          .self$weather_data$days[[day_info]]$sunrise <- value
        } else {
          stop("Invalid input value for day_info")
        }
      }, error = function(e) {
        stop(e)
      })
    },

    #' @description
    #' Retrieves the Unix timestamp for the sunrise time for a specific day.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @return The sunrise Unix timestamp for the specified day.
    #' @export
    get_sunriseEpoch_on_day = function(day_info) {
      tryCatch({
        if (is.character(day_info)) {
          sunriseEpoch <- NULL
          for (day in .self$weather_data$days) {
            if (day$datetime == day_info) {
              sunriseEpoch <- day$sunriseEpoch
              break
            }
          }
        } else if (is.numeric(day_info) && length(day_info) == 1) {
          sunriseEpoch <- .self$weather_data$days[[day_info]]$sunriseEpoch
        } else {
          stop("Invalid input value for day_info")
        }
        return(sunriseEpoch)
      }, error = function(e) {
        message("Error accessing sunrise epoch data on this day: ", e$message)
        return(NULL)
      })
    },

    #' @description
    #' Sets the Unix timestamp for the sunrise time for a specific day.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @param value The new sunrise Unix timestamp value to set.
    #' @export
    set_sunriseEpoch_on_day = function(day_info, value) {
      tryCatch({
        if (is.character(day_info)) {
          for (i in seq_along(.self$weather_data$days)) {
            if (.self$weather_data$days[[i]]$datetime == day_info) {
              .self$weather_data$days[[i]]$sunriseEpoch <- value
              break
            }
          }
        } else if (is.numeric(day_info) && length(day_info) == 1) {
          .self$weather_data$days[[day_info]]$sunriseEpoch <- value
        } else {
          stop("Invalid input value for day_info")
        }
      }, error = function(e) {
        stop(e)
      })
    },

    #' @description
    #' Retrieves the sunset time for a specific day identified by date or index.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @return The sunset time for the specified day.
    #' @export
    get_sunset_on_day = function(day_info) {
      tryCatch({
        if (is.character(day_info)) {
          sunset <- NULL
          for (day in .self$weather_data$days) {
            if (day$datetime == day_info) {
              sunset <- day$sunset
              break
            }
          }
        } else if (is.numeric(day_info) && length(day_info) == 1) {
          sunset <- .self$weather_data$days[[day_info]]$sunset
        } else {
          stop("Invalid input value for day_info")
        }
        return(sunset)
      }, error = function(e) {
        message("Error accessing sunset data on this day: ", e$message)
        return(NULL)
      })
    },

    #' @description
    #' Sets the sunset time for a specific day identified by date or index.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @param value The new sunset time value to set.
    #' @export
    set_sunset_on_day = function(day_info, value) {
      tryCatch({
        if (is.character(day_info)) {
          for (i in seq_along(.self$weather_data$days)) {
            if (.self$weather_data$days[[i]]$datetime == day_info) {
              .self$weather_data$days[[i]]$sunset <- value
              break
            }
          }
        } else if (is.numeric(day_info) && length(day_info) == 1) {
          .self$weather_data$days[[day_info]]$sunset <- value
        } else {
          stop("Invalid input value for day_info")
        }
      }, error = function(e) {
        stop(e)
      })
    },

    #' @description
    #' Retrieves the Unix timestamp for the sunset time for a specific day.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @return The sunset Unix timestamp for the specified day.
    #' @export
    get_sunsetEpoch_on_day = function(day_info) {
      tryCatch({
        if (is.character(day_info)) {
          sunsetEpoch <- NULL
          for (day in .self$weather_data$days) {
            if (day$datetime == day_info) {
              sunsetEpoch <- day$sunsetEpoch
              break
            }
          }
        } else if (is.numeric(day_info) && length(day_info) == 1) {
          sunsetEpoch <- .self$weather_data$days[[day_info]]$sunsetEpoch
        } else {
          stop("Invalid input value for day_info")
        }
        return(sunsetEpoch)
      }, error = function(e) {
        message("Error accessing sunset epoch data on this day: ", e$message)
        return(NULL)
      })
    },

    #' @description
    #' Sets the Unix timestamp for the sunset time for a specific day.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @param value The new sunset Unix timestamp value to set.
    #' @export
    set_sunsetEpoch_on_day = function(day_info, value) {
      tryCatch({
        if (is.character(day_info)) {
          for (i in seq_along(.self$weather_data$days)) {
            if (.self$weather_data$days[[i]]$datetime == day_info) {
              .self$weather_data$days[[i]]$sunsetEpoch <- value
              break
            }
          }
        } else if (is.numeric(day_info) && length(day_info) == 1) {
          .self$weather_data$days[[day_info]]$sunsetEpoch <- value
        } else {
          stop("Invalid input value for day_info")
        }
      }, error = function(e) {
        stop(e)
      })
    },

    #' @description
    #' Retrieves the moon phase for a specific day identified by date or index.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @return The moon phase for the specified day.
    #' @export
    get_moonphase_on_day = function(day_info) {
      tryCatch({
        if (is.character(day_info)) {
          moonphase <- NULL
          for (day in .self$weather_data$days) {
            if (day$datetime == day_info) {
              moonphase <- day$moonphase
              break
            }
          }
        } else if (is.numeric(day_info) && length(day_info) == 1) {
          moonphase <- .self$weather_data$days[[day_info]]$moonphase
        } else {
          stop("Invalid input value for day_info")
        }
        return(moonphase)
      }, error = function(e) {
        message("Error accessing moon phase data on this day: ", e$message)
        return(NULL)
      })
    },

    #' @description
    #' Sets the moon phase for a specific day identified by date or index.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @param value The new moon phase value to set.
    #' @export
    set_moonphase_on_day = function(day_info, value) {
      tryCatch({
        if (is.character(day_info)) {
          for (i in seq_along(.self$weather_data$days)) {
            if (.self$weather_data$days[[i]]$datetime == day_info) {
              .self$weather_data$days[[i]]$moonphase <- value
              break
            }
          }
        } else if (is.numeric(day_info) && length(day_info) == 1) {
          .self$weather_data$days[[day_info]]$moonphase <- value
        } else {
          stop("Invalid input value for day_info")
        }
      }, error = function(e) {
        stop(e)
      })
    },

    #' @description
    #' Retrieves the weather conditions for a specific day identified by date or index.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @return The weather conditions for the specified day.
    #' @export
    get_conditions_on_day = function(day_info) {
      tryCatch({
        if (is.character(day_info)) {
          conditions <- NULL
          for (day in .self$weather_data$days) {
            if (day$datetime == day_info) {
              conditions <- day$conditions
              break
            }
          }
        } else if (is.numeric(day_info) && length(day_info) == 1) {
          conditions <- .self$weather_data$days[[day_info]]$conditions
        } else {
          stop("Invalid input value for day_info")
        }
        return(conditions)
      }, error = function(e) {
        message("Error accessing conditions data on this day: ", e$message)
        return(NULL)
      })
    },

    #' @description
    #' Sets the weather conditions for a specific day identified by date or index.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @param value The new conditions value to set.
    #' @export
    set_conditions_on_day = function(day_info, value) {
      tryCatch({
        if (is.character(day_info)) {
          for (i in seq_along(.self$weather_data$days)) {
            if (.self$weather_data$days[[i]]$datetime == day_info) {
              .self$weather_data$days[[i]]$conditions <- value
              break
            }
          }
        } else if (is.numeric(day_info) && length(day_info) == 1) {
          .self$weather_data$days[[day_info]]$conditions <- value
        } else {
          stop("Invalid input value for day_info")
        }
      }, error = function(e) {
        stop(e)
      })
    },

    #' @description
    #' Retrieves the weather description for a specific day identified by date or index.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @return The weather description for the specified day.
    #' @export
    get_description_on_day = function(day_info) {
      tryCatch({
        if (is.character(day_info)) {
          description <- NULL
          for (day in .self$weather_data$days) {
            if (day$datetime == day_info) {
              description <- day$description
              break
            }
          }
        } else if (is.numeric(day_info) && length(day_info) == 1) {
          description <- .self$weather_data$days[[day_info]]$description
        } else {
          stop("Invalid input value for day_info")
        }
        return(description)
      }, error = function(e) {
        message("Error accessing description data on this day: ", e$message)
        return(NULL)
      })
    },

    #' @description
    #' Sets the weather description for a specific day identified by date or index.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @param value The new description to set.
    #' @export
    set_description_on_day = function(day_info, value) {
      tryCatch({
        if (is.character(day_info)) {
          for (i in seq_along(.self$weather_data$days)) {
            if (.self$weather_data$days[[i]]$datetime == day_info) {
              .self$weather_data$days[[i]]$description <- value
              break
            }
          }
        } else if (is.numeric(day_info) && length(day_info) == 1) {
          .self$weather_data$days[[day_info]]$description <- value
        } else {
          stop("Invalid input value for day_info")
        }
      }, error = function(e) {
        stop(e)
      })
    },

    #' @description
    #' Retrieves the weather icon for a specific day identified by date or index.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @return The weather icon for the specified day.
    #' @export
    get_icon_on_day = function(day_info) {
      tryCatch({
        if (is.character(day_info)) {
          icon <- NULL
          for (day in .self$weather_data$days) {
            if (day$datetime == day_info) {
              icon <- day$icon
              break
            }
          }
        } else if (is.numeric(day_info) && length(day_info) == 1) {
          icon <- .self$weather_data$days[[day_info]]$icon
        } else {
          stop("Invalid input value for day_info")
        }
        return(icon)
      }, error = function(e) {
        message("Error accessing icon data on this day: ", e$message)
        return(NULL)
      })
    },

    #' @description
    #' Sets the weather icon for a specific day identified by date or index.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @param value The new icon to set.
    #' @export
    set_icon_on_day = function(day_info, value) {
      tryCatch({
        if (is.character(day_info)) {
          for (i in seq_along(.self$weather_data$days)) {
            if (.self$weather_data$days[[i]]$datetime == day_info) {
              .self$weather_data$days[[i]]$icon <- value
              break
            }
          }
        } else if (is.numeric(day_info) && length(day_info) == 1) {
          .self$weather_data$days[[day_info]]$icon <- value
        } else {
          stop("Invalid input value for day_info")
        }
      }, error = function(e) {
        stop(e)
      })
    },

    #' @description
    #' Retrieves the weather stations data for a specific day identified by date or index.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @return The list of weather stations active on the specified day.
    #' @export
    get_stations_on_day = function(day_info) {
      tryCatch({
        if (is.character(day_info)) {
          stations <- NULL
          for (day in .self$weather_data$days) {
            if (day$datetime == day_info) {
              stations <- day$stations
              break
            }
          }
        } else if (is.numeric(day_info) && length(day_info) == 1) {
          stations <- .self$weather_data$days[[day_info]]$stations
        } else {
          stop("Invalid input value for day_info")
        }
        return(stations)
      }, error = function(e) {
        message("Error accessing stations data on this day: ", e$message)
        return(NULL)
      })
    },

    #' @description
    #' Sets the weather stations data for a specific day identified by date or index.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @param value The new list of weather stations to set.
    #' @export
    set_stations_on_day = function(day_info, value) {
      tryCatch({
        if (is.character(day_info)) {
          for (i in seq_along(.self$weather_data$days)) {
            if (.self$weather_data$days[[i]]$datetime == day_info) {
              .self$weather_data$days[[i]]$stations <- value
              break
            }
          }
        } else if (is.numeric(day_info) && length(day_info) == 1) {
          .self$weather_data$days[[day_info]]$stations <- value
        } else {
          stop("Invalid input value for day_info")
        }
      }, error = function(e) {
        stop(e)
      })
    },

    #' @description
    #' Retrieves hourly weather data for a specific day identified by date or index.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @param elements Optional list of keys to filter the hourly data.
    #' @return A list of hourly data dictionaries for the specified day.
    #' @examples
    #' weather <- Weather$new(api_key = "your_api_key")
    #' weather$fetch_weather_data("New York", "2023-01-01", "2023-01-07")
    #' weather$get_hourlyData_on_day("2023-01-01")
    get_hourlyData_on_day = function(day_info, elements = list()) {
      tryCatch({
        if (is.character(day_info)) {
          hourly_data <- NULL
          for (day in .self$weather_data$days) {
            if (day$datetime == day_info) {
              hourly_data <- day$hours
              break
            }
          }
        } else if (is.numeric(day_info) && length(day_info) == 1) {
          hourly_data <- .self$weather_data$days[[day_info]]$hours
        } else {
          stop("Invalid input value for day_info")
        }

        if (length(elements) > 0) {
          hourlyData <- lapply(hourly_data, function(hour) {
            extract_sublist_by_keys(hour, elements)
          })
        } else {
          hourlyData <- hourly_data
        }
        return(hourlyData)
      }, error = function(e) {
        message("Error accessing hourly data: ", e$message)
        return(list())
      })
    },

    #' @description
    #' Sets the hourly weather data for a specific day identified by date or index.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @param data The new list of hourly weather data dictionaries to set.
    #' @examples
    #' weather <- Weather$new(api_key = "your_api_key")
    #' weather$fetch_weather_data("New York", "2023-01-01", "2023-01-07")
    #' new_hourly_data <- list(list(datetime = "2023-01-01T00:00:00", temp = 5.0))
    #' weather$set_hourlyData_on_day("2023-01-01", new_hourly_data)
    set_hourlyData_on_day = function(day_info, data) {
      tryCatch({
        if (is.character(day_info)) {
          for (i in seq_along(.self$weather_data$days)) {
            if (.self$weather_data$days[[i]]$datetime == day_info) {
              .self$weather_data$days[[i]]$hours <- data
              break
            }
          }
        } else if (is.numeric(day_info) && length(day_info) == 1) {
          .self$weather_data$days[[day_info]]$hours <- data
        } else {
          stop("Invalid input value for day_info")
        }
      }, error = function(e) {
        stop(e)
      })
    },

    #' @description
    #' Retrieves weather data for a specific date and time from the weather data collection.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @param time_info A character string ('HH:MM:SS') or an integer index identifying the time.
    #' @param elements Optional list of keys to filter the data.
    #' @return A list of weather data for the specified date and time.
    #' @examples
    #' weather <- Weather$new(api_key = "your_api_key")
    #' weather$get_data_at_datetime("2023-01-01", "12:00:00")
    get_data_at_datetime = function(day_info, time_info, elements = list()) {
      tryCatch({
        day_idx <- Weather$get_idx_from_datetimeArg(.self$weather_data$days, day_info)
        time_idx <- Weather$get_idx_from_datetimeArg(.self$weather_data$days[[day_idx]]$hours, time_info)
        data <- .self$weather_data$days[[day_idx]]$hours[[time_idx]]
        if (length(elements) > 0) {
          data <- extract_sublist_by_keys(data, elements)
        }
        return(data)
      }, error = function(e) {
        message("An exception occurred: ", e$message)
        return(NULL)
      })
    },

    #' @description
    #' Sets weather data for a specific date and time in the weather data collection.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @param time_info A character string ('HH:MM:SS') or an integer index identifying the time.
    #' @param data The new data to set for the specified datetime.
    #' @examples
    #' weather <- Weather$new(api_key = "your_api_key")
    #' new_data <- list(temp = 15.0)
    #' weather$set_data_at_datetime("2023-01-01", "12:00:00", new_data)
    set_data_at_datetime = function(day_info, time_info, data) {
      tryCatch({
        day_idx <- Weather$get_idx_from_datetimeArg(.self$weather_data$days, day_info)
        time_idx <- Weather$get_idx_from_datetimeArg(.self$weather_data$days[[day_idx]]$hours, time_info)
        .self$weather_data$days[[day_idx]]$hours[[time_idx]] <- Weather$set_item_by_datetimeIdx(.self$weather_data$days[[day_idx]]$hours, time_idx, data)
      }, error = function(e) {
        stop(e)
      })
    },

    #' @description
    #' Updates weather data for a specific date and time in the weather data collection.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @param time_info A character string ('HH:MM:SS') or an integer index identifying the time.
    #' @param data The new data to update for the specified datetime.
    #' @examples
    #' weather <- Weather$new(api_key = "your_api_key")
    #' update_data <- list(temp = 20.0)
    #' weather$update_data_at_datetime("2023-01-01", "12:00:00", update_data)
    update_data_at_datetime = function(day_info, time_info, data) {
      tryCatch({
        day_idx <- Weather$get_idx_from_datetimeArg(.self$weather_data$days, day_info)
        time_idx <- Weather$get_idx_from_datetimeArg(.self$weather_data$days[[day_idx]]$hours, time_info)
        .self$weather_data$days[[day_idx]]$hours[[time_idx]] <- Weather$update_item_by_datetimeIdx(.self$weather_data$days[[day_idx]]$hours, time_idx, data)
      }, error = function(e) {
        stop(e)
      })
    },

    #' @description
    #' Retrieves the epoch time for a specific datetime within the weather data.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @param time_info A character string ('HH:MM:SS') or an integer index identifying the time.
    #' @return The epoch time corresponding to the specific day and time.
    #' @examples
    #' weather <- Weather$new(api_key = "your_api_key")
    #' weather$get_datetimeEpoch_at_datetime("2023-01-01", "12:00:00")
    get_datetimeEpoch_at_datetime = function(day_info, time_info) {
      tryCatch({
        day_idx <- Weather$get_idx_from_datetimeArg(.self$weather_data$days, day_info)
        time_idx <- Weather$get_idx_from_datetimeArg(.self$weather_data$days[[day_idx]]$hours, time_info)
        datetimeEpoch <- .self$weather_data$days[[day_idx]]$hours[[time_idx]]$datetimeEpoch
        return(datetimeEpoch)
      }, error = function(e) {
        message("An exception occurred: ", e$message)
        return(NULL)
      })
    },

    #' @description
    #' Sets the epoch time for a specific datetime within the weather data.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @param time_info A character string ('HH:MM:SS') or an integer index identifying the time.
    #' @param value The epoch time value to set.
    #' @examples
    #' weather <- Weather$new(api_key = "your_api_key")
    #' weather$set_datetimeEpoch_at_datetime("2023-01-01", "12:00:00", 1672531200)
    set_datetimeEpoch_at_datetime = function(day_info, time_info, value) {
      tryCatch({
        day_idx <- Weather$get_idx_from_datetimeArg(.self$weather_data$days, day_info)
        time_idx <- Weather$get_idx_from_datetimeArg(.self$weather_data$days[[day_idx]]$hours, time_info)
        .self$weather_data$days[[day_idx]]$hours[[time_idx]]$datetimeEpoch <- value
      }, error = function(e) {
        stop(e)
      })
    },

    #' @description
    #' Retrieves the temperature for a specific datetime within the weather data.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @param time_info A character string ('HH:MM:SS') or an integer index identifying the time.
    #' @return The temperature at the specified datetime.
    #' @examples
    #' weather <- Weather$new(api_key = "your_api_key")
    #' weather$get_temp_at_datetime("2023-01-01", "12:00:00")
    get_temp_at_datetime = function(day_info, time_info) {
      tryCatch({
        day_idx <- Weather$get_idx_from_datetimeArg(.self$weather_data$days, day_info)
        time_idx <- Weather$get_idx_from_datetimeArg(.self$weather_data$days[[day_idx]]$hours, time_info)
        temp <- .self$weather_data$days[[day_idx]]$hours[[time_idx]]$temp
      }, error = function(e) {
        message("An exception occurred: ", e$message)
        return(NULL)
      })
    },

    #' @description
    #' Sets the temperature for a specific datetime within the weather data.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @param time_info A character string ('HH:MM:SS') or an integer index identifying the time.
    #' @param value The temperature value to set.
    #' @examples
    #' weather <- Weather$new(api_key = "your_api_key")
    #' weather$set_temp_at_datetime("2023-01-01", "12:00:00", 25.0)
    set_temp_at_datetime = function(day_info, time_info, value) {
      tryCatch({
        day_idx <- Weather$get_idx_from_datetimeArg(.self$weather_data$days, day_info)
        time_idx <- Weather$get_idx_from_datetimeArg(.self$weather_data$days[[day_idx]]$hours, time_info)
        .self$weather_data$days[[day_idx]]$hours[[time_idx]]$temp <- value
      }, error = function(e) {
        stop(e)
      })
    },

    #' @description
    #' Retrieves the 'feels like' temperature for a specific datetime within the weather data.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @param time_info A character string ('HH:MM:SS') or an integer index identifying the time.
    #' @return The 'feels like' temperature at the specified datetime.
    #' @examples
    #' weather <- Weather$new(api_key = "your_api_key")
    #' weather$get_feelslike_at_datetime("2023-01-01", "12:00:00")
    get_feelslike_at_datetime = function(day_info, time_info) {
      tryCatch({
        day_idx <- Weather$get_idx_from_datetimeArg(.self$weather_data$days, day_info)
        time_idx <- Weather$get_idx_from_datetimeArg(.self$weather_data$days[[day_idx]]$hours, time_info)
        feelslike <- .self$weather_data$days[[day_idx]]$hours[[time_idx]]$feelslike
        return(feelslike)
      }, error = function(e) {
        message("An exception occurred: ", e$message)
        return(NULL)
      })
    },

    #' @description
    #' Sets the 'feels like' temperature for a specific datetime within the weather data.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @param time_info A character string ('HH:MM:SS') or an integer index identifying the time.
    #' @param value The 'feels like' temperature value to set.
    #' @examples
    #' weather <- Weather$new(api_key = "your_api_key")
    #' weather$set_feelslike_at_datetime("2023-01-01", "12:00:00", 20.0)
    set_feelslike_at_datetime = function(day_info, time_info, value) {
      tryCatch({
        day_idx <- Weather$get_idx_from_datetimeArg(.self$weather_data$days, day_info)
        time_idx <- Weather$get_idx_from_datetimeArg(.self$weather_data$days[[day_idx]]$hours, time_info)
        .self$weather_data$days[[day_idx]]$hours[[time_idx]]$feelslike <- value
      }, error = function(e) {
        stop(e)
      })
    },

    #' @description
    #' Retrieves the humidity for a specific datetime within the weather data.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @param time_info A character string ('HH:MM:SS') or an integer index identifying the time.
    #' @return The humidity percentage at the specified datetime.
    #' @examples
    #' weather <- Weather$new(api_key = "your_api_key")
    #' weather$get_humidity_at_datetime("2023-01-01", "12:00:00")
    get_humidity_at_datetime = function(day_info, time_info) {
      tryCatch({
        day_idx <- Weather$get_idx_from_datetimeArg(.self$weather_data$days, day_info)
        time_idx <- Weather$get_idx_from_datetimeArg(.self$weather_data$days[[day_idx]]$hours, time_info)
        humidity <- .self$weather_data$days[[day_idx]]$hours[[time_idx]]$humidity
        return(humidity)
      }, error = function(e) {
        message("An exception occurred: ", e$message)
        return(NULL)
      })
    },

    #' @description
    #' Sets the humidity for a specific datetime within the weather data.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @param time_info A character string ('HH:MM:SS') or an integer index identifying the time.
    #' @param value The humidity percentage to set.
    #' @examples
    #' weather <- Weather$new(api_key = "your_api_key")
    #' weather$set_humidity_at_datetime("2023-01-01", "12:00:00", 60.0)
    set_humidity_at_datetime = function(day_info, time_info, value) {
      tryCatch({
        day_idx <- Weather$get_idx_from_datetimeArg(.self$weather_data$days, day_info)
        time_idx <- Weather$get_idx_from_datetimeArg(.self$weather_data$days[[day_idx]]$hours, time_info)
        humidity <- .self$weather_data$days[[day_idx]]$hours[[time_idx]]$humidity <- value
      }, error = function(e) {
        stop(e)
      })
    },

    #' @description
    #' Retrieves the dew point temperature for a specific datetime within the weather data.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @param time_info A character string ('HH:MM:SS') or an integer index identifying the time.
    #' @return The dew point temperature at the specified datetime.
    #' @examples
    #' weather <- Weather$new(api_key = "your_api_key")
    #' weather$get_dew_at_datetime("2023-01-01", "12:00:00")
    get_dew_at_datetime = function(day_info, time_info) {
      tryCatch({
        day_idx <- Weather$get_idx_from_datetimeArg(.self$weather_data$days, day_info)
        time_idx <- Weather$get_idx_from_datetimeArg(.self$weather_data$days[[day_idx]]$hours, time_info)
        dew <- .self$weather_data$days[[day_idx]]$hours[[time_idx]]$dew
        return(dew)
      }, error = function(e) {
        message("An exception occurred: ", e$message)
        return(NULL)
      })
    },

    #' @description
    #' Sets the dew point temperature for a specific datetime within the weather data.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @param time_info A character string ('HH:MM:SS') or an integer index identifying the time.
    #' @param value The dew point temperature to set.
    #' @examples
    #' weather <- Weather$new(api_key = "your_api_key")
    #' weather$set_dew_at_datetime("2023-01-01", "12:00:00", 5.0)
    set_dew_at_datetime = function(day_info, time_info, value) {
      tryCatch({
        day_idx <- Weather$get_idx_from_datetimeArg(.self$weather_data$days, day_info)
        time_idx <- Weather$get_idx_from_datetimeArg(.self$weather_data$days[[day_idx]]$hours, time_info)
        .self$weather_data$days[[day_idx]]$hours[[time_idx]]$dew <- value
      }, error = function(e) {
        stop(e)
      })
    },

    #' @description
    #' Retrieves the precipitation amount for a specific datetime within the weather data.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @param time_info A character string ('HH:MM:SS') or an integer index identifying the time.
    #' @return The precipitation amount at the specified datetime.
    #' @examples
    #' weather <- Weather$new(api_key = "your_api_key")
    #' weather$get_precip_at_datetime("2023-01-01", "12:00:00")
    get_precip_at_datetime = function(day_info, time_info) {
      tryCatch({
        day_idx <- Weather$get_idx_from_datetimeArg(.self$weather_data$days, day_info)
        time_idx <- Weather$get_idx_from_datetimeArg(.self$weather_data$days[[day_idx]]$hours, time_info)
        precip <- .self$weather_data$days[[day_idx]]$hours[[time_idx]]$precip
        return(precip)
      }, error = function(e) {
        message("An exception occurred: ", e$message)
        return(NULL)
      })
    },

    #' @description
    #' Sets the precipitation amount for a specific datetime within the weather data.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @param time_info A character string ('HH:MM:SS') or an integer index identifying the time.
    #' @param value The precipitation amount to set.
    #' @examples
    #' weather <- Weather$new(api_key = "your_api_key")
    #' weather$set_precip_at_datetime("2023-01-01", "12:00:00", 0.5)
    set_precip_at_datetime = function(day_info, time_info, value) {
      tryCatch({
        day_idx <- Weather$get_idx_from_datetimeArg(.self$weather_data$days, day_info)
        time_idx <- Weather$get_idx_from_datetimeArg(.self$weather_data$days[[day_idx]]$hours, time_info)
        .self$weather_data$days[[day_idx]]$hours[[time_idx]]$precip <- value
      }, error = function(e) {
        stop(e)
      })
    },

    #' @description
    #' Retrieves the probability of precipitation for a specific datetime within the weather data.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @param time_info A character string ('HH:MM:SS') or an integer index identifying the time.
    #' @return The probability of precipitation at the specified datetime.
    #' @examples
    #' weather <- Weather$new(api_key = "your_api_key")
    #' weather$get_precipprob_at_datetime("2023-01-01", "12:00:00")
    get_precipprob_at_datetime = function(day_info, time_info) {
      tryCatch({
        day_idx <- Weather$get_idx_from_datetimeArg(.self$weather_data$days, day_info)
        time_idx <- Weather$get_idx_from_datetimeArg(.self$weather_data$days[[day_idx]]$hours, time_info)
        precipprob <- .self$weather_data$days[[day_idx]]$hours[[time_idx]]$precipprob
        return(precipprob)
      }, error = function(e) {
        message("An exception occurred: ", e$message)
        return(NULL)
      })
    },

    #' @description
    #' Sets the probability of precipitation for a specific datetime within the weather data.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @param time_info A character string ('HH:MM:SS') or an integer index identifying the time.
    #' @param value The probability of precipitation to set.
    #' @examples
    #' weather <- Weather$new(api_key = "your_api_key")
    #' weather$set_precipprob_at_datetime("2023-01-01", "12:00:00", 50.0)
    set_precipprob_at_datetime = function(day_info, time_info, value) {
      tryCatch({
        day_idx <- Weather$get_idx_from_datetimeArg(.self$weather_data$days, day_info)
        time_idx <- Weather$get_idx_from_datetimeArg(.self$weather_data$days[[day_idx]]$hours, time_info)
        .self$weather_data$days[[day_idx]]$hours[[time_idx]]$precipprob <- value
      }, error = function(e) {
        stop(e)
      })
    },

    #' @description
    #' Retrieves the snow amount for a specific datetime within the weather data.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @param time_info A character string ('HH:MM:SS') or an integer index identifying the time.
    #' @return The snow amount at the specified datetime.
    #' @examples
    #' weather <- Weather$new(api_key = "your_api_key")
    #' weather$get_snow_at_datetime("2023-01-01", "12:00:00")
    get_snow_at_datetime = function(day_info, time_info) {
      tryCatch({
        day_idx <- Weather$get_idx_from_datetimeArg(.self$weather_data$days, day_info)
        time_idx <- Weather$get_idx_from_datetimeArg(.self$weather_data$days[[day_idx]]$hours, time_info)
        snow <- .self$weather_data$days[[day_idx]]$hours[[time_idx]]$snow
        return(snow)
      }, error = function(e) {
        message("An exception occurred: ", e$message)
        return(NULL)
      })
    },

    #' @description
    #' Sets the snow amount for a specific datetime within the weather data.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @param time_info A character string ('HH:MM:SS') or an integer index identifying the time.
    #' @param value The snow amount to set.
    #' @examples
    #' weather <- Weather$new(api_key = "your_api_key")
    #' weather$set_snow_at_datetime("2023-01-01", "12:00:00", 2.0)
    set_snow_at_datetime = function(day_info, time_info, value) {
      tryCatch({
        day_idx <- Weather$get_idx_from_datetimeArg(.self$weather_data$days, day_info)
        time_idx <- Weather$get_idx_from_datetimeArg(.self$weather_data$days[[day_idx]]$hours, time_info)
        .self$weather_data$days[[day_idx]]$hours[[time_idx]]$snow <- value
      }, error = function(e) {
        stop(e)
      })
    },

    #' @description
    #' Retrieves the snow depth for a specific datetime within the weather data.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @param time_info A character string ('HH:MM:SS') or an integer index identifying the time.
    #' @return The snow depth at the specified datetime.
    #' @examples
    #' weather <- Weather$new(api_key = "your_api_key")
    #' weather$get_snowdepth_at_datetime("2023-01-01", "12:00:00")
    get_snowdepth_at_datetime = function(day_info, time_info) {
      tryCatch({
        day_idx <- Weather$get_idx_from_datetimeArg(.self$weather_data$days, day_info)
        time_idx <- Weather$get_idx_from_datetimeArg(.self$weather_data$days[[day_idx]]$hours, time_info)
        snowdepth <- .self$weather_data$days[[day_idx]]$hours[[time_idx]]$snowdepth
        return(snowdepth)
      }, error = function(e) {
        message("An exception occurred: ", e$message)
        return(NULL)
      })
    },

    #' @description
    #' Sets the snow depth for a specific datetime within the weather data.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @param time_info A character string ('HH:MM:SS') or an integer index identifying the time.
    #' @param value The snow depth to set.
    #' @examples
    #' weather <- Weather$new(api_key = "your_api_key")
    #' weather$set_snowdepth_at_datetime("2023-01-01", "12:00:00", 5.0)
    set_snowdepth_at_datetime = function(day_info, time_info, value) {
      tryCatch({
        day_idx <- Weather$get_idx_from_datetimeArg(.self$weather_data$days, day_info)
        time_idx <- Weather$get_idx_from_datetimeArg(.self$weather_data$days[[day_idx]]$hours, time_info)
        .self$weather_data$days[[day_idx]]$hours[[time_idx]]$snowdepth <- value
      }, error = function(e) {
        stop(e)
      })
    },

    #' @description
    #' Retrieves the type of precipitation for a specific datetime within the weather data.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @param time_info A character string ('HH:MM:SS') or an integer index identifying the time.
    #' @return The type of precipitation at the specified datetime.
    #' @examples
    #' weather <- Weather$new(api_key = "your_api_key")
    #' weather$get_preciptype_at_datetime("2023-01-01", "12:00:00")
    get_preciptype_at_datetime = function(day_info, time_info) {
      tryCatch({
        day_idx <- Weather$get_idx_from_datetimeArg(.self$weather_data$days, day_info)
        time_idx <- Weather$get_idx_from_datetimeArg(.self$weather_data$days[[day_idx]]$hours, time_info)
        preciptype <- .self$weather_data$days[[day_idx]]$hours[[time_idx]]$preciptype
        return(preciptype)
      }, error = function(e) {
        message("An exception occurred: ", e$message)
        return(NULL)
      })
    },

    #' @description
    #' Sets the type of precipitation for a specific datetime within the weather data.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @param time_info A character string ('HH:MM:SS') or an integer index identifying the time.
    #' @param value The type of precipitation to set.
    #' @examples
    #' weather <- Weather$new(api_key = "your_api_key")
    #' weather$set_preciptype_at_datetime("2023-01-01", "12:00:00", "rain")
    set_preciptype_at_datetime = function(day_info, time_info, value) {
      tryCatch({
        day_idx <- Weather$get_idx_from_datetimeArg(.self$weather_data$days, day_info)
        time_idx <- Weather$get_idx_from_datetimeArg(.self$weather_data$days[[day_idx]]$hours, time_info)
        .self$weather_data$days[[day_idx]]$hours[[time_idx]]$preciptype <- value
      }, error = function(e) {
        stop(e)
      })
    },

    #' @description
    #' Retrieves the wind gust speed for a specific datetime within the weather data.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @param time_info A character string ('HH:MM:SS') or an integer index identifying the time.
    #' @return The wind gust speed at the specified datetime.
    #' @examples
    #' weather <- Weather$new(api_key = "your_api_key")
    #' weather$get_windgust_at_datetime("2023-01-01", "12:00:00")
    get_windgust_at_datetime = function(day_info, time_info) {
      tryCatch({
        day_idx <- Weather$get_idx_from_datetimeArg(.self$weather_data$days, day_info)
        time_idx <- Weather$get_idx_from_datetimeArg(.self$weather_data$days[[day_idx]]$hours, time_info)
        windgust <- .self$weather_data$days[[day_idx]]$hours[[time_idx]]$windgust
        return(windgust)
      }, error = function(e) {
        message("An exception occurred: ", e$message)
        return(NULL)
      })
    },

    #' @description
    #' Sets the wind gust speed for a specific datetime within the weather data.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @param time_info A character string ('HH:MM:SS') or an integer index identifying the time.
    #' @param value The wind gust speed to set.
    #' @examples
    #' weather <- Weather$new(api_key = "your_api_key")
    #' weather$set_windgust_at_datetime("2023-01-01", "12:00:00", 30.0)
    set_windgust_at_datetime = function(day_info, time_info, value) {
      tryCatch({
        day_idx <- Weather$get_idx_from_datetimeArg(.self$weather_data$days, day_info)
        time_idx <- Weather$get_idx_from_datetimeArg(.self$weather_data$days[[day_idx]]$hours, time_info)
        .self$weather_data$days[[day_idx]]$hours[[time_idx]]$windgust <- value
      }, error = function(e) {
        stop(e)
      })
    },

    #' @description
    #' Retrieves the wind speed for a specific datetime within the weather data.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @param time_info A character string ('HH:MM:SS') or an integer index identifying the time.
    #' @return The wind speed at the specified datetime.
    #' @examples
    #' weather <- Weather$new(api_key = "your_api_key")
    #' weather$get_windspeed_at_datetime("2023-01-01", "12:00:00")
    get_windspeed_at_datetime = function(day_info, time_info) {
      tryCatch({
        day_idx <- Weather$get_idx_from_datetimeArg(.self$weather_data$days, day_info)
        time_idx <- Weather$get_idx_from_datetimeArg(.self$weather_data$days[[day_idx]]$hours, time_info)
        windspeed <- .self$weather_data$days[[day_idx]]$hours[[time_idx]]$windspeed
        return(windspeed)
      }, error = function(e) {
        message("An exception occurred: ", e$message)
        return(NULL)
      })
    },

    #' @description
    #' Sets the wind speed for a specific datetime within the weather data.
    #'
    #' @param day_info A character string ('YYYY-MM-DD') or an integer index identifying the day.
    #' @param time_info A character string ('HH:MM:SS') or an integer index identifying the time.
    #' @param value The wind speed to set.
    #' @examples
    #' weather <- Weather$new(api_key = "your_api_key")
    #' weather$set_windspeed_at_datetime("2023-01-01", "12:00:00", 15.0)
    set_windspeed_at_datetime = function(day_info, time_info, value) {
      tryCatch({
        day_idx <- Weather$get_idx_from_datetimeArg(.self$weather_data$days, day_info)
        time_idx <- Weather$get_idx_from_datetimeArg(.self$weather_data$days[[day_idx]]$hours, time_info)
        .self$weather_data$days[[day_idx]]$hours[[time_idx]]$windspeed <- value
      }, error = function(e) {
        stop(e)
      })
    },

    #' @description
    #' Retrieves the wind direction for a specific datetime within the weather data.
    #'
    #' @param day_info (char|int) A day identifier, which can be a date string (YYYY-MM-DD) or an index.
    #' @param time_info (char|int) A time identifier, which can be a time string (HH:MM:SS) or an index.
    #' @return float The wind direction at the specified datetime.
    get_winddir_at_datetime = function(day_info, time_info) {
      tryCatch({
        day_idx <- .self$get_idx_from_datetimeArg(.self$weather_data$days, day_info)
        time_idx <- .self$get_idx_from_datetimeArg(.self$weather_data$days[[day_idx]]$hours, time_info)
        winddir <- .self$weather_data$days[[day_idx]]$hours[[time_idx]]$winddir
        return(winddir)
      }, error = function(e) {
        message("An exception occurred: ", e$message)
        return(NULL)
      })
    },

    #' @description
    #' Sets the wind direction for a specific datetime within the weather data.
    #'
    #' @param day_info (char|int) A day identifier, which can be a date string (YYYY-MM-DD) or an index.
    #' @param time_info (char|int) A time identifier, which can be a time string (HH:MM:SS) or an index.
    #' @param value (float) The wind direction to be set.
    set_winddir_at_datetime = function(day_info, time_info, value) {
      tryCatch({
        day_idx <- .self$get_idx_from_datetimeArg(.self$weather_data$days, day_info)
        time_idx <- .self$get_idx_from_datetimeArg(.self$weather_data$days[[day_idx]]$hours, time_info)
        .self$weather_data$days[[day_idx]]$hours[[time_idx]]$winddir <- value
      }, error = function(e) {
        stop(e$message)
      })
    },

    #' @description
    #' Retrieves the atmospheric pressure for a specific datetime within the weather data.
    #'
    #' @param day_info (char|int) A day identifier, which can be a date string (YYYY-MM-DD) or an index.
    #' @param time_info (char|int) A time identifier, which can be a time string (HH:MM:SS) or an index.
    #' @return float The atmospheric pressure at the specified datetime.
    get_pressure_at_datetime = function(day_info, time_info) {
      tryCatch({
        day_idx <- .self$get_idx_from_datetimeArg(.self$weather_data$days, day_info)
        time_idx <- .self$get_idx_from_datetimeArg(.self$weather_data$days[[day_idx]]$hours, time_info)
        pressure <- .self$weather_data$days[[day_idx]]$hours[[time_idx]]$pressure
        return(pressure)
      }, error = function(e) {
        message("An exception occurred: ", e$message)
        return(NULL)
      })
    },

    #' @description
    #' Sets the atmospheric pressure for a specific datetime within the weather data.
    #'
    #' @param day_info (char|int) A day identifier, which can be a date string (YYYY-MM-DD) or an index.
    #' @param time_info (char|int) A time identifier, which can be a time string (HH:MM:SS) or an index.
    #' @param value (float) The atmospheric pressure to be set.
    set_pressure_at_datetime = function(day_info, time_info, value) {
      tryCatch({
        day_idx <- .self$get_idx_from_datetimeArg(.self$weather_data$days, day_info)
        time_idx <- .self$get_idx_from_datetimeArg(.self$weather_data$days[[day_idx]]$hours, time_info)
        .self$weather_data$days[[day_idx]]$hours[[time_idx]]$pressure <- value
      }, error = function(e) {
        stop(e$message)
      })
    },

    #' @description
    #' Retrieves the visibility for a specific datetime within the weather data.
    #'
    #' @param day_info (char|int) A day identifier, which can be a date string (YYYY-MM-DD) or an index.
    #' @param time_info (char|int) A time identifier, which can be a time string (HH:MM:SS) or an index.
    #' @return float The visibility at the specified datetime.
    get_visibility_at_datetime = function(day_info, time_info) {
      tryCatch({
        day_idx <- .self$get_idx_from_datetimeArg(.self$weather_data$days, day_info)
        time_idx <- .self$get_idx_from_datetimeArg(.self$weather_data$days[[day_idx]]$hours, time_info)
        visibility <- .self$weather_data$days[[day_idx]]$hours[[time_idx]]$visibility
        return(visibility)
      }, error = function(e) {
        message("An exception occurred: ", e$message)
        return(NULL)
      })
    },

    #' @description
    #' Sets the visibility for a specific datetime within the weather data.
    #'
    #' @param day_info (char|int) A day identifier, which can be a date string (YYYY-MM-DD) or an index.
    #' @param time_info (char|int) A time identifier, which can be a time string (HH:MM:SS) or an index.
    #' @param value (float) The visibility to be set.
    set_visibility_at_datetime = function(day_info, time_info, value) {
      tryCatch({
        day_idx <- .self$get_idx_from_datetimeArg(.self$weather_data$days, day_info)
        time_idx <- .self$get_idx_from_datetimeArg(.self$weather_data$days[[day_idx]]$hours, time_info)
        .self$weather_data$days[[day_idx]]$hours[[time_idx]]$visibility <- value
      }, error = function(e) {
        stop(e$message)
      })
    },

    #' @description
    #' Retrieves the cloud cover for a specific datetime within the weather data.
    #'
    #' @param day_info (char|int) A day identifier, which can be a date string (YYYY-MM-DD) or an index.
    #' @param time_info (char|int) A time identifier, which can be a time string (HH:MM:SS) or an index.
    #' @return float The cloud cover at the specified datetime.
    get_cloudcover_at_datetime = function(day_info, time_info) {
      tryCatch({
        day_idx <- .self$get_idx_from_datetimeArg(.self$weather_data$days, day_info)
        time_idx <- .self$get_idx_from_datetimeArg(.self$weather_data$days[[day_idx]]$hours, time_info)
        cloudcover <- .self$weather_data$days[[day_idx]]$hours[[time_idx]]$cloudcover
        return(cloudcover)
      }, error = function(e) {
        message("An exception occurred: ", e$message)
        return(NULL)
      })
    },

    #' @description
    #' Sets the cloud cover for a specific datetime within the weather data.
    #'
    #' @param day_info (char|int) A day identifier, which can be a date string (YYYY-MM-DD) or an index.
    #' @param time_info (char|int) A time identifier, which can be a time string (HH:MM:SS) or an index.
    #' @param value (float) The cloud cover to be set.
    set_cloudcover_at_datetime = function(day_info, time_info, value) {
      tryCatch({
        day_idx <- .self$get_idx_from_datetimeArg(.self$weather_data$days, day_info)
        time_idx <- .self$get_idx_from_datetimeArg(.self$weather_data$days[[day_idx]]$hours, time_info)
        .self$weather_data$days[[day_idx]]$hours[[time_idx]]$cloudcover <- value
      }, error = function(e) {
        stop(e$message)
      })
    },

    #' @description
    #' Retrieves the solar radiation for a specific datetime within the weather data.
    #'
    #' @param day_info (char|int) A day identifier, which can be a date string (YYYY-MM-DD) or an index.
    #' @param time_info (char|int) A time identifier, which can be a time string (HH:MM:SS) or an index.
    #' @return float The solar radiation at the specified datetime.
    get_solarradiation_at_datetime = function(day_info, time_info) {
      tryCatch({
        day_idx <- .self$get_idx_from_datetimeArg(.self$weather_data$days, day_info)
        time_idx <- .self$get_idx_from_datetimeArg(.self$weather_data$days[[day_idx]]$hours, time_info)
        solarradiation <- .self$weather_data$days[[day_idx]]$hours[[time_idx]]$solarradiation
        return(solarradiation)
      }, error = function(e) {
        message("An exception occurred: ", e$message)
        return(NULL)
      })
    },

    #' @description
    #' Sets the solar radiation for a specific datetime within the weather data.
    #'
    #' @param day_info (char|int) A day identifier, which can be a date string (YYYY-MM-DD) or an index.
    #' @param time_info (char|int) A time identifier, which can be a time string (HH:MM:SS) or an index.
    #' @param value (float) The solar radiation to be set.
    set_solarradiation_at_datetime = function(day_info, time_info, value) {
      tryCatch({
        day_idx <- .self$get_idx_from_datetimeArg(.self$weather_data$days, day_info)
        time_idx <- .self$get_idx_from_datetimeArg(.self$weather_data$days[[day_idx]]$hours, time_info)
        .self$weather_data$days[[day_idx]]$hours[[time_idx]]$solarradiation <- value
      }, error = function(e) {
        stop(e$message)
      })
    },

    #' @description
    #' Retrieves the solar energy for a specific datetime within the weather data.
    #'
    #' @param day_info (char|int) A day identifier, which can be a date string (YYYY-MM-DD) or an index.
    #' @param time_info (char|int) A time identifier, which can be a time string (HH:MM:SS) or an index.
    #' @return float The solar energy at the specified datetime.
    get_solarenergy_at_datetime = function(day_info, time_info) {
      tryCatch({
        day_idx <- .self$get_idx_from_datetimeArg(.self$weather_data$days, day_info)
        time_idx <- .self$get_idx_from_datetimeArg(.self$weather_data$days[[day_idx]]$hours, time_info)
        solarenergy <- .self$weather_data$days[[day_idx]]$hours[[time_idx]]$solarenergy
        return(solarenergy)
      }, error = function(e) {
        message("An exception occurred: ", e$message)
        return(NULL)
      })
    },

    #' @description
    #' Sets the solar energy for a specific datetime within the weather data.
    #'
    #' @param day_info (char|int) A day identifier, which can be a date string (YYYY-MM-DD) or an index.
    #' @param time_info (char|int) A time identifier, which can be a time string (HH:MM:SS) or an index.
    #' @param value (float) The solar energy to be set.
    set_solarenergy_at_datetime = function(day_info, time_info, value) {
      tryCatch({
        day_idx <- .self$get_idx_from_datetimeArg(.self$weather_data$days, day_info)
        time_idx <- .self$get_idx_from_datetimeArg(.self$weather_data$days[[day_idx]]$hours, time_info)
        .self$weather_data$days[[day_idx]]$hours[[time_idx]]$solarenergy <- value
      }, error = function(e) {
        stop(e$message)
      })
    },

    #' @description
    #' Retrieves the UV index for a specific datetime within the weather data.
    #' UV index: A value between 0 and 10 indicating the level of ultra violet (UV) exposure for that hour or day.
    #'
    #' @param day_info (char|int) A day identifier, which can be a date string (YYYY-MM-DD) or an index.
    #' @param time_info (char|int) A time identifier, which can be a time string (HH:MM:SS) or an index.
    #' @return float The UV index at the specified datetime.
    get_uvindex_at_datetime = function(day_info, time_info) {
      tryCatch({
        day_idx <- .self$get_idx_from_datetimeArg(.self$weather_data$days, day_info)
        time_idx <- .self$get_idx_from_datetimeArg(.self$weather_data$days[[day_idx]]$hours, time_info)
        uvindex <- .self$weather_data$days[[day_idx]]$hours[[time_idx]]$uvindex
        return(uvindex)
      }, error = function(e) {
        message("An exception occurred: ", e$message)
        return(NULL)
      })
    },

    #' @description
    #' Sets the UV index for a specific datetime within the weather data.
    #'
    #' @param day_info (char|int) A day identifier, which can be a date string (YYYY-MM-DD) or an index.
    #' @param time_info (char|int) A time identifier, which can be a time string (HH:MM:SS) or an index.
    #' @param value (float) The UV index to be set.
    set_uvindex_at_datetime = function(day_info, time_info, value) {
      tryCatch({
        day_idx <- .self$get_idx_from_datetimeArg(.self$weather_data$days, day_info)
        time_idx <- .self$get_idx_from_datetimeArg(.self$weather_data$days[[day_idx]]$hours, time_info)
        .self$weather_data$days[[day_idx]]$hours[[time_idx]]$uvindex <- value
      }, error = function(e) {
        stop(e$message)
      })
    },

    #' @description
    #' Retrieves the severe risk for a specific datetime within the weather data.
    #'
    #' @param day_info (char|int) A day identifier, which can be a date string (YYYY-MM-DD) or an index.
    #' @param time_info (char|int) A time identifier, which can be a time string (HH:MM:SS) or an index.
    #' @return float The severe risk at the specified datetime.
    get_severerisk_at_datetime = function(day_info, time_info) {
      tryCatch({
        day_idx <- .self$get_idx_from_datetimeArg(.self$weather_data$days, day_info)
        time_idx <- .self$get_idx_from_datetimeArg(.self$weather_data$days[[day_idx]]$hours, time_info)
        severerisk <- .self$weather_data$days[[day_idx]]$hours[[time_idx]]$severerisk
        return(severerisk)
      }, error = function(e) {
        message("An exception occurred: ", e$message)
        return(NULL)
      })
    },

    #' @description
    #' Sets the severe risk for a specific datetime within the weather data.
    #'
    #' @param day_info (char|int) A day identifier, which can be a date string (YYYY-MM-DD) or an index.
    #' @param time_info (char|int) A time identifier, which can be a time string (HH:MM:SS) or an index.
    #' @param value (float) The severe risk to be set.
    set_severerisk_at_datetime = function(day_info, time_info, value) {
      tryCatch({
        day_idx <- .self$get_idx_from_datetimeArg(.self$weather_data$days, day_info)
        time_idx <- .self$get_idx_from_datetimeArg(.self$weather_data$days[[day_idx]]$hours, time_info)
        .self$weather_data$days[[day_idx]]$hours[[time_idx]]$severerisk <- value
      }, error = function(e) {
        stop(e$message)
      })
    },

    #' @description
    #' Retrieves the conditions for a specific datetime within the weather data.
    #'
    #' @param day_info (char|int) A day identifier, which can be a date string (YYYY-MM-DD) or an index.
    #' @param time_info (char|int) A time identifier, which can be a time string (HH:MM:SS) or an index.
    #' @return string The conditions at the specified datetime.
    get_conditions_at_datetime = function(day_info, time_info) {
      tryCatch({
        day_idx <- .self$get_idx_from_datetimeArg(.self$weather_data$days, day_info)
        time_idx <- .self$get_idx_from_datetimeArg(.self$weather_data$days[[day_idx]]$hours, time_info)
        conditions <- .self$weather_data$days[[day_idx]]$hours[[time_idx]]$conditions
        return(conditions)
      }, error = function(e) {
        message("An exception occurred: ", e$message)
        return(NULL)
      })
    },

    #' @description
    #' Sets the conditions for a specific datetime within the weather data.
    #'
    #' @param day_info (char|int) A day identifier, which can be a date string (YYYY-MM-DD) or an index.
    #' @param time_info (char|int) A time identifier, which can be a time string (HH:MM:SS) or an index.
    #' @param value (string) The conditions to be set.
    set_conditions_at_datetime = function(day_info, time_info, value) {
      tryCatch({
        day_idx <- .self$get_idx_from_datetimeArg(.self$weather_data$days, day_info)
        time_idx <- .self$get_idx_from_datetimeArg(.self$weather_data$days[[day_idx]]$hours, time_info)
        .self$weather_data$days[[day_idx]]$hours[[time_idx]]$conditions <- value
      }, error = function(e) {
        stop(e$message)
      })
    },

    #' @description
    #' Retrieves the weather icon for a specific datetime within the weather data.
    #'
    #' @param day_info (char|int) A day identifier, which can be a date string (YYYY-MM-DD) or an index.
    #' @param time_info (char|int) A time identifier, which can be a time string (HH:MM:SS) or an index.
    #' @return string The weather icon at the specified datetime.
    get_icon_at_datetime = function(day_info, time_info) {
      tryCatch({
        day_idx <- .self$get_idx_from_datetimeArg(.self$weather_data$days, day_info)
        time_idx <- .self$get_idx_from_datetimeArg(.self$weather_data$days[[day_idx]]$hours, time_info)
        icon <- .self$weather_data$days[[day_idx]]$hours[[time_idx]]$icon
        return(icon)
      }, error = function(e) {
        message("An exception occurred: ", e$message)
        return(NULL)
      })
    },

    #' @description
    #' Sets the weather icon for a specific datetime within the weather data.
    #'
    #' @param day_info (char|int) A day identifier, which can be a date string (YYYY-MM-DD) or an index.
    #' @param time_info (char|int) A time identifier, which can be a time string (HH:MM:SS) or an index.
    #' @param value (string) The weather icon to be set.
    set_icon_at_datetime = function(day_info, time_info, value) {
      tryCatch({
        day_idx <- .self$get_idx_from_datetimeArg(.self$weather_data$days, day_info)
        time_idx <- .self$get_idx_from_datetimeArg(.self$weather_data$days[[day_idx]]$hours, time_info)
        .self$weather_data$days[[day_idx]]$hours[[time_idx]]$icon <- value
      }, error = function(e) {
        stop(e$message)
      })
    },

    #' @description
    #' Retrieves the weather stations that were used for creating the observation for a specific datetime within the weather data.
    #'
    #' @param day_info (char|int) A day identifier, which can be a date string (YYYY-MM-DD) or an index.
    #' @param time_info (char|int) A time identifier, which can be a time string (HH:MM:SS) or an index.
    #' @return character vector The weather stations that were used for creating the observation at the specified datetime.
    get_stations_at_datetime = function(day_info, time_info) {
      tryCatch({
        day_idx <- .self$get_idx_from_datetimeArg(.self$weather_data$days, day_info)
        time_idx <- .self$get_idx_from_datetimeArg(.self$weather_data$days[[day_idx]]$hours, time_info)
        stations <- .self$weather_data$days[[day_idx]]$hours[[time_idx]]$stations
        return(stations)
      }, error = function(e) {
        message("An exception occurred: ", e$message)
        return(NULL)
      })
    },

    #' @description
    #' Sets the weather stations that were used for creating the observation for a specific datetime within the weather data.
    #'
    #' @param day_info (char|int) A day identifier, which can be a date string (YYYY-MM-DD) or an index.
    #' @param time_info (char|int) A time identifier, which can be a time string (HH:MM:SS) or an index.
    #' @param value (character vector) The weather stations to be set.
    set_stations_at_datetime = function(day_info, time_info, value) {
      tryCatch({
        day_idx <- .self$get_idx_from_datetimeArg(.self$weather_data$days, day_info)
        time_idx <- .self$get_idx_from_datetimeArg(.self$weather_data$days[[day_idx]]$hours, time_info)
        .self$weather_data$days[[day_idx]]$hours[[time_idx]]$stations <- value
      }, error = function(e) {
        stop(e$message)
      })
    },

    #' @description
    #' Retrieves the type of weather data used for this weather object for a specific datetime within the weather data.
    #'
    #' @param day_info (char|int) A day identifier, which can be a date string (YYYY-MM-DD) or an index.
    #' @param time_info (char|int) A time identifier, which can be a time string (HH:MM:SS) or an index.
    #' @return string The type of weather data used for this weather object at the specified datetime.
    #'   (Values include historical observation ("obs"), forecast ("fcst"), historical forecast ("histfcst") or statistical forecast ("stats").
    #'   If multiple types are used in the same day, "comb" is used. Today a combination of historical observations and forecast data.)
    get_source_at_datetime = function(day_info, time_info) {
      tryCatch({
        day_idx <- .self$get_idx_from_datetimeArg(.self$weather_data$days, day_info)
        time_idx <- .self$get_idx_from_datetimeArg(.self$weather_data$days[[day_idx]]$hours, time_info)
        source <- .self$weather_data$days[[day_idx]]$hours[[time_idx]]$source
        return(source)
      }, error = function(e) {
        message("An exception occurred: ", e$message)
        return(NULL)
      })
    },

    #' @description
    #' Sets the type of weather data used for this weather object for a specific datetime within the weather data.
    #'
    #' @param day_info (char|int) A day identifier, which can be a date string (YYYY-MM-DD) or an index.
    #' @param time_info (char|int) A time identifier, which can be a time string (HH:MM:SS) or an index.
    #' @param value (string) The type of weather data to be set.
    set_source_at_datetime = function(day_info, time_info, value) {
      tryCatch({
        day_idx <- .self$get_idx_from_datetimeArg(.self$weather_data$days, day_info)
        time_idx <- .self$get_idx_from_datetimeArg(.self$weather_data$days[[day_idx]]$hours, time_info)
        .self$weather_data$days[[day_idx]]$hours[[time_idx]]$source <- value
      }, error = function(e) {
        stop(e$message)
      })
    },

    #' @description
    #' Clears all weather data stored in the object.
    clear_weather_data = function() {
      .self$weather_data <- list()
    }
  )
)
